document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="07"><label for="07">Macros et langages de script</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/shared/main0601.html?DbPAR=BASIC">Aide LibreOffice Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01000000.html?DbPAR=BASIC">Programmation avec LibreOffice Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/00000002.html?DbPAR=BASIC">Glossaire LibreOffice Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01010210.html?DbPAR=BASIC">Concepts de base</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01020000.html?DbPAR=BASIC">Syntaxe</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01050000.html?DbPAR=BASIC">Basic-IDE LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01030100.html?DbPAR=BASIC">Présentation de l&#39;EDI</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01030200.html?DbPAR=BASIC">Éditeur Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01050100.html?DbPAR=BASIC">Fenêtre Témoin</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/main0211.html?DbPAR=BASIC">Barre de macro</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/05060700.html?DbPAR=BASIC">Macro</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Prise en charge des macros VBA</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Références des commandes</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/shared/01020300.html?DbPAR=BASIC">Utilisation des procédures et des fonctions</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01020500.html?DbPAR=BASIC">Bibliothèques, modules et boîtes de dialogue</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Fonctions, déclarations et opérateurs</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010000.html?DbPAR=BASIC">Fonctions d&#39;entrée/sortie à l&#39;écran</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020000.html?DbPAR=BASIC">Fonctions d&#39;entrée/sortie de fichier</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030000.html?DbPAR=BASIC">Fonctions de date et d&#39;heure</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fonctions de traitement des erreurs</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060000.html?DbPAR=BASIC">Opérateurs logiques</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070000.html?DbPAR=BASIC">Opérateurs mathématiques</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080000.html?DbPAR=BASIC">Fonctions numériques</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090000.html?DbPAR=BASIC">Contrôle de l&#39;exécution du programme</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100000.html?DbPAR=BASIC">Variables</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03040000.html?DbPAR=BASIC">Constantes Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03110000.html?DbPAR=BASIC">Opérateurs de comparaison</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120000.html?DbPAR=BASIC">Chaînes</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">Objets UNO</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Fonctions exclusivement VBA</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130000.html?DbPAR=BASIC">Autres commandes</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Liste alphabétique des fonctions, déclarations et opérateurs</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080601.html?DbPAR=BASIC">Fonction Abs</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060100.html?DbPAR=BASIC">Opérateur AND</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104200.html?DbPAR=BASIC">Fonction Array</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120101.html?DbPAR=BASIC">Fonction Asc</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120111.html?DbPAR=BASIC">Fonction AscW</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080101.html?DbPAR=BASIC">Fonction Atn</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130100.html?DbPAR=BASIC">Instruction Beep</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010301.html?DbPAR=BASIC">Fonction Blue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100100.html?DbPAR=BASIC">Fonction CBool</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120105.html?DbPAR=BASIC">Fonction CByte</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100050.html?DbPAR=BASIC">Fonction CCur</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030116.html?DbPAR=BASIC">Fonction CDateFromUnoDateTime</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030115.html?DbPAR=BASIC">Fonction CDateToUnoDateTime</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030114.html?DbPAR=BASIC">Fonction CDateFromUnoTime</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030113.html?DbPAR=BASIC">Fonction CDateToUnoTime</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030112.html?DbPAR=BASIC">Fonction CDateFromUnoDate</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030111.html?DbPAR=BASIC">Fonction CDateToUnoDate</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030108.html?DbPAR=BASIC">Fonction CDateFromIso</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030107.html?DbPAR=BASIC">Fonction CDateToIso</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100300.html?DbPAR=BASIC">Fonction CDate</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100400.html?DbPAR=BASIC">Fonction CDbl</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100060.html?DbPAR=BASIC">Fonction CDec</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100500.html?DbPAR=BASIC">Fonction CInt</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100600.html?DbPAR=BASIC">Fonction CLng</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100900.html?DbPAR=BASIC">Fonction CSng</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101000.html?DbPAR=BASIC">Fonction CStr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090401.html?DbPAR=BASIC">Instruction Call</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020401.html?DbPAR=BASIC">Instruction ChDir</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020402.html?DbPAR=BASIC">Instruction ChDrive</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090402.html?DbPAR=BASIC">Fonction Choose</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120102.html?DbPAR=BASIC">Fonction Chr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120112.html?DbPAR=BASIC">Fonction ChrW [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020101.html?DbPAR=BASIC">Instruction Close</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03110100.html?DbPAR=BASIC">Opérateurs de comparaison</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100700.html?DbPAR=BASIC">Instruction Const</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120313.html?DbPAR=BASIC">Fonction ConvertFromURL</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120312.html?DbPAR=BASIC">Fonction ConvertToURL</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080102.html?DbPAR=BASIC">Fonction Cos</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03132400.html?DbPAR=BASIC">Fonction CreateObject</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131800.html?DbPAR=BASIC">Fonction CreateUnoDialog</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03132000.html?DbPAR=BASIC">Fonction CreateUnoListener</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131600.html?DbPAR=BASIC">Fonction CreateUnoService</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131500.html?DbPAR=BASIC">Fonction CreateUnoStruct</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03132300.html?DbPAR=BASIC">Fonction CreateUnoValue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020403.html?DbPAR=BASIC">Fonction CurDir</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100070.html?DbPAR=BASIC">Fonction CVar</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03100080.html?DbPAR=BASIC">Fonction CVErr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030110.html?DbPAR=BASIC">Fonction DateAdd</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030120.html?DbPAR=BASIC">Fonction DateDiff</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030130.html?DbPAR=BASIC">Fonction DatePart</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030101.html?DbPAR=BASIC">Fonction DateSerial</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030102.html?DbPAR=BASIC">Fonction DateValue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030301.html?DbPAR=BASIC">Instruction Date</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030103.html?DbPAR=BASIC">Fonction Day</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140000.html?DbPAR=BASIC">Fonction DDB [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090403.html?DbPAR=BASIC">Instruction Declare</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101100.html?DbPAR=BASIC">Instruction DefBool</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101300.html?DbPAR=BASIC">Instruction DefDate</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101400.html?DbPAR=BASIC">Instruction DefDbl</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101500.html?DbPAR=BASIC">Instruction DefInt</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101600.html?DbPAR=BASIC">Instruction DefLng</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03101700.html?DbPAR=BASIC">Instruction DefObj</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102000.html?DbPAR=BASIC">Instruction DefVar</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104300.html?DbPAR=BASIC">Fonction DimArray</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102100.html?DbPAR=BASIC">Instruction Dim</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020404.html?DbPAR=BASIC">Fonction Dir</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090201.html?DbPAR=BASIC">Instruction Do...Loop</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03110100.html?DbPAR=BASIC">Opérateurs de comparaison</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090404.html?DbPAR=BASIC">Instruction End</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/enum.html?DbPAR=BASIC">Instruction Enum</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130800.html?DbPAR=BASIC">Fonction Environ</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020301.html?DbPAR=BASIC">Fonction Eof</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104600.html?DbPAR=BASIC">Fonction EqualUnoObjects</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060200.html?DbPAR=BASIC">Opérateur Eqv</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03050100.html?DbPAR=BASIC">Fonction Erl</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03050200.html?DbPAR=BASIC">Fonction Err</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03050300.html?DbPAR=BASIC">Fonction Error</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03050000.html?DbPAR=BASIC">Fonctions de traitement des erreurs</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090412.html?DbPAR=BASIC">Instruction Exit</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080201.html?DbPAR=BASIC">Fonction Exp</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020405.html?DbPAR=BASIC">Fonction FileAttr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020406.html?DbPAR=BASIC">Instruction FileCopy</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020407.html?DbPAR=BASIC">Fonction FileDateTime</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020415.html?DbPAR=BASIC">Fonction FileExists</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020408.html?DbPAR=BASIC">Fonction FileLen</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103800.html?DbPAR=BASIC">Fonction FindObject</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103900.html?DbPAR=BASIC">Fonction FindPropertyObject</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fonction Fix</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090202.html?DbPAR=BASIC">Instruction For...Next</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120301.html?DbPAR=BASIC">Fonction Format</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03150000.html?DbPAR=BASIC">Fonction FormatDateTime [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03170010.html?DbPAR=BASIC">Fonction FormatNumber [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080503.html?DbPAR=BASIC">Fonction Frac</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020102.html?DbPAR=BASIC">Fonction FreeFile</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090405.html?DbPAR=BASIC">Fonction FreeLibrary</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090406.html?DbPAR=BASIC">Instruction Function</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090400.html?DbPAR=BASIC">Autres instructions</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140001.html?DbPAR=BASIC">Fonction FV [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080300.html?DbPAR=BASIC">Génération de nombres aléatoires</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020409.html?DbPAR=BASIC">Fonction GetAttr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03132500.html?DbPAR=BASIC">Fonction GetDefaultContext</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03132100.html?DbPAR=BASIC">Fonction GetGuiType</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131700.html?DbPAR=BASIC">Fonction GetProcessServiceManager</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">Fonction GetPathSeparator</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131000.html?DbPAR=BASIC">Fonction GetSolarVersion</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130700.html?DbPAR=BASIC">Fonction GetSystemTicks</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020201.html?DbPAR=BASIC">Instruction Get</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090301.html?DbPAR=BASIC">Instruction GoSub...Return</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090302.html?DbPAR=BASIC">Instruction GoTo</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010302.html?DbPAR=BASIC">Fonction Green</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104400.html?DbPAR=BASIC">Fonction HasUnoInterfaces</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080801.html?DbPAR=BASIC">Fonction Hex</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030201.html?DbPAR=BASIC">Fonction Hour</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090103.html?DbPAR=BASIC">Instruction IIf</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090101.html?DbPAR=BASIC">Instruction If...Then...Else</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060300.html?DbPAR=BASIC">Opérateur Imp</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120401.html?DbPAR=BASIC">Fonction InStr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120411.html?DbPAR=BASIC">Fonction InStrRev [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03160000.html?DbPAR=BASIC">Fonction Input [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010201.html?DbPAR=BASIC">Fonction InputBox</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020202.html?DbPAR=BASIC">Instruction Input#</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080502.html?DbPAR=BASIC">Fonction Int</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140002.html?DbPAR=BASIC">Fonction IPmt [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140003.html?DbPAR=BASIC">Fonction IRR [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102200.html?DbPAR=BASIC">Fonction IsArray</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102300.html?DbPAR=BASIC">Fonction IsDate</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102400.html?DbPAR=BASIC">Fonction IsEmpty</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104000.html?DbPAR=BASIC">Fonction IsMissing</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102600.html?DbPAR=BASIC">Fonction IsNull</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102700.html?DbPAR=BASIC">Fonction IsNumeric</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102800.html?DbPAR=BASIC">Fonction IsObject</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104500.html?DbPAR=BASIC">Fonction IsUnoStruct</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120315.html?DbPAR=BASIC">Fonction Join</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020410.html?DbPAR=BASIC">Instruction Kill</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102900.html?DbPAR=BASIC">Fonction LBound</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120302.html?DbPAR=BASIC">Fonction LCase</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120304.html?DbPAR=BASIC">Instruction LSet</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120305.html?DbPAR=BASIC">Fonction LTrim</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120303.html?DbPAR=BASIC">Fonction Left</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120402.html?DbPAR=BASIC">Fonction Len</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103100.html?DbPAR=BASIC">Instruction Let</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020203.html?DbPAR=BASIC">Instruction Line Input #</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020302.html?DbPAR=BASIC">Fonction Loc</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020303.html?DbPAR=BASIC">Fonction Lof</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080202.html?DbPAR=BASIC">Fonction Log</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120306.html?DbPAR=BASIC">Fonction Mid, Instruction Mid</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030202.html?DbPAR=BASIC">Fonction Minute</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140004.html?DbPAR=BASIC">Fonction MIRR [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020411.html?DbPAR=BASIC">Instruction MkDir</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070600.html?DbPAR=BASIC">Opérateur Mod</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030104.html?DbPAR=BASIC">Fonction Month</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03150002.html?DbPAR=BASIC">Fonction MonthName [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010102.html?DbPAR=BASIC">Fonction MsgBox</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010101.html?DbPAR=BASIC">Instruction MsgBox</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020412.html?DbPAR=BASIC">Instruction Name</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060400.html?DbPAR=BASIC">Opérateur Not</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030203.html?DbPAR=BASIC">Fonction Now</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140005.html?DbPAR=BASIC">Fonction NPer [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140006.html?DbPAR=BASIC">Fonction NPV [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080000.html?DbPAR=BASIC">Fonctions numériques</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080802.html?DbPAR=BASIC">Fonction Oct</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03050500.html?DbPAR=BASIC">Instruction On Error GoTo ... Resume</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090303.html?DbPAR=BASIC">Instruction On...GoSub ; Instruction On...GoTo</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020103.html?DbPAR=BASIC">Instruction Open</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103200.html?DbPAR=BASIC">Instruction Option Base</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103300.html?DbPAR=BASIC">Instruction Option Explicit</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103350.html?DbPAR=BASIC">Instruction Option VBASupport</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (dans l&#39;instruction d&#39;une fonction)</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060500.html?DbPAR=BASIC">Opérateur Or</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/partition.html?DbPAR=BASIC">Fonction Partition</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140007.html?DbPAR=BASIC">Fonction Pmt [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140008.html?DbPAR=BASIC">Fonction PPmt [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140009.html?DbPAR=BASIC">Fonction PV [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010103.html?DbPAR=BASIC">Instruction Print</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103400.html?DbPAR=BASIC">Instruction Public</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020204.html?DbPAR=BASIC">Instruction Put</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010304.html?DbPAR=BASIC">Fonction QBColor</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140010.html?DbPAR=BASIC">Fonction Rate [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010305.html?DbPAR=BASIC">Fonction RGB</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120308.html?DbPAR=BASIC">Instruction RSet</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120309.html?DbPAR=BASIC">Fonction RTrim</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080301.html?DbPAR=BASIC">Instruction Randomize</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03102101.html?DbPAR=BASIC">Instruction ReDim</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03010303.html?DbPAR=BASIC">Fonction Red</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090407.html?DbPAR=BASIC">Instruction Rem</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/replace.html?DbPAR=BASIC">Fonction Remplacer</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020104.html?DbPAR=BASIC">Instruction Reset</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120307.html?DbPAR=BASIC">Fonction Right</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020413.html?DbPAR=BASIC">Instruction RmDir</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080302.html?DbPAR=BASIC">Fonction Rnd</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03170000.html?DbPAR=BASIC">Fonction Round [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030204.html?DbPAR=BASIC">Fonction Second</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020304.html?DbPAR=BASIC">Fonction Seek</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020305.html?DbPAR=BASIC">Instruction Seek</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090102.html?DbPAR=BASIC">Instruction Select...Case</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020414.html?DbPAR=BASIC">Instruction SetAttr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103700.html?DbPAR=BASIC">Instruction Set</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080701.html?DbPAR=BASIC">Fonction Sgn</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130500.html?DbPAR=BASIC">Fonction Shell</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080103.html?DbPAR=BASIC">Fonction Sin</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140011.html?DbPAR=BASIC">Fonction SLN [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120201.html?DbPAR=BASIC">Fonctions Space et Spc</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120201.html?DbPAR=BASIC">Fonctions Space et Spc</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120314.html?DbPAR=BASIC">Fonction Split</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080401.html?DbPAR=BASIC">Fonction Sqr</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080400.html?DbPAR=BASIC">Calcul de la racine carrée</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103500.html?DbPAR=BASIC">Instruction Static</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090408.html?DbPAR=BASIC">Instruction Stop</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120403.html?DbPAR=BASIC">Fonction StrComp</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120103.html?DbPAR=BASIC">Fonction Str</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120412.html?DbPAR=BASIC">Fonction StrReverse [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120202.html?DbPAR=BASIC">Fonction String</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090409.html?DbPAR=BASIC">Instruction Sub</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090410.html?DbPAR=BASIC">Fonction Switch</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03140012.html?DbPAR=BASIC">Fonction SYD [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080104.html?DbPAR=BASIC">Fonction Tan</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030205.html?DbPAR=BASIC">Fonction TimeSerial</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030206.html?DbPAR=BASIC">Fonction TimeValue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030302.html?DbPAR=BASIC">Instruction Time</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030303.html?DbPAR=BASIC">Fonction Timer</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03080100.html?DbPAR=BASIC">Fonctions trigonométriques</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120311.html?DbPAR=BASIC">Fonction Trim</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131300.html?DbPAR=BASIC">Fonction TwipsPerPixelX</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03131400.html?DbPAR=BASIC">Fonction TwipsPerPixelY</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090413.html?DbPAR=BASIC">Instruction Type</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103600.html?DbPAR=BASIC">Fonction TypeName ; Fonction VarType</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03103000.html?DbPAR=BASIC">Fonction UBound</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120310.html?DbPAR=BASIC">Fonction UCase</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03120104.html?DbPAR=BASIC">Fonction Val</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130600.html?DbPAR=BASIC">Instruction Wait</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03130610.html?DbPAR=BASIC">Instruction WaitUntil</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030105.html?DbPAR=BASIC">Fonction WeekDay</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03150001.html?DbPAR=BASIC">Fonction WeekdayName [VBA]</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090203.html?DbPAR=BASIC">Instruction While...Wend</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03090411.html?DbPAR=BASIC">Instruction With</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03020205.html?DbPAR=BASIC">Instruction Write</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03060600.html?DbPAR=BASIC">Opérateur XOR</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03030106.html?DbPAR=BASIC">Fonction Year</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070100.html?DbPAR=BASIC">Opérateur "-"</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070200.html?DbPAR=BASIC">Opérateur "*"</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070300.html?DbPAR=BASIC">Opérateur "+"</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070400.html?DbPAR=BASIC">Opérateur "/"</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03070500.html?DbPAR=BASIC">Opérateur "^"</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Bibliothèques Basic avancé</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Bibliothèque Tools</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">Bibliothèque DEPOT</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">Bibliothèque EURO</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">Bibliothèque FORMWIZARD</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">Bibliothèque GIMMICKS</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">Bibliothèque SCHEDULE</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">Bibliothèque SCRIPTBINDINGLIBRARY</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">Bibliothèque TEMPLATE</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Repères</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/macro_recording.html?DbPAR=BASIC">Enregistrement d&#39;une macro</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/control_properties.html?DbPAR=BASIC">Modification des propriétés des contrôles dans l&#39;éditeur de boîte de dialogue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/insert_control.html?DbPAR=BASIC">Création de contrôles dans l&#39;éditeur de boîte de dialogue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/sample_code.html?DbPAR=BASIC">Exemples de programmation pour les contrôles dans l&#39;éditeur de boîte de dialogue</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Ouvrir une boîte de dialogue avec Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">Création d&#39;une boîte de dialogue Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01030400.html?DbPAR=BASIC">Gestion des bibliothèques et des modules</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01020100.html?DbPAR=BASIC">Utilisation des variables</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01020200.html?DbPAR=BASIC">Utilisation des objets</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01030300.html?DbPAR=BASIC">Débogage d&#39;un programme Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/shared/01040000.html?DbPAR=BASIC">Macros déclenchées par des événements</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Exemples de programmation Basic</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic vers Python</a></li>\
    <li><a target="_top" href="fr/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Aide des scripts Python</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/python/main0000.html?DbPAR=BASIC">Scripts Python</a></li>\
    <li><a target="_top" href="fr/text/sbasic/python/python_ide.html?DbPAR=BASIC">EDI pour Python</a></li>\
    <li><a target="_top" href="fr/text/sbasic/python/python_locations.html?DbPAR=BASIC">Organisation des scripts Python</a></li>\
    <li><a target="_top" href="fr/text/sbasic/python/python_shell.html?DbPAR=BASIC">Shell interactif Python</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programmation avec Python</label><ul>\
    <li><a target="_top" href="fr/text/sbasic/python/python_programming.html?DbPAR=BASIC">Programmation avec Python</a></li>\
    <li><a target="_top" href="fr/text/sbasic/python/python_examples.html?DbPAR=BASIC">Exemples Python</a></li>\
    <li><a target="_top" href="fr/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python vers Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Classeurs (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/scalc/main0000.html?DbPAR=CALC">Bienvenue dans l&#39;aide de LibreOffice Calc</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0503.html?DbPAR=CALC">Fonctionnalités de LibreOffice Calc</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/keyboard.html?DbPAR=CALC">Raccourcis clavier (accessibilité LibreOffice Calc)</a></li>\
    <li><a target="_top" href="fr/text/scalc/04/01020000.html?DbPAR=CALC">Raccourcis clavier pour les classeurs</a></li>\
    <li><a target="_top" href="fr/text/scalc/05/02140000.html?DbPAR=CALC">Codes d&#39;erreur dans LibreOffice Calc</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060112.html?DbPAR=CALC">Add-in de programmation de LibreOffice Calc</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/main.html?DbPAR=CALC">Instructions d&#39;utilisation de LibreOffice Calc</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">Références des menus et des commandes</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">Menus</label><ul>\
    <li><a target="_top" href="fr/text/scalc/main0100.html?DbPAR=CALC">Menus</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0101.html?DbPAR=CALC">Fichier</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0102.html?DbPAR=CALC">Édition</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0103.html?DbPAR=CALC">Affichage</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0104.html?DbPAR=CALC">Insérer</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0105.html?DbPAR=CALC">Format</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0116.html?DbPAR=CALC">Feuille</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0112.html?DbPAR=CALC">Données</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0106.html?DbPAR=CALC">Outils</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0107.html?DbPAR=CALC">Fenêtre</a></li>\
    <li><a target="_top" href="fr/text/shared/main0108.html?DbPAR=CALC">Aide</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">Barres d&#39;outils</label><ul>\
    <li><a target="_top" href="fr/text/scalc/main0200.html?DbPAR=CALC">Barres d&#39;outils</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0202.html?DbPAR=CALC">Barre Formatage</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0203.html?DbPAR=CALC">Barre Propriétés de l&#39;objet de dessin</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0205.html?DbPAR=CALC">Barre Formatage de texte</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0206.html?DbPAR=CALC">Barre de formule</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0208.html?DbPAR=CALC">Barre d&#39;état</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0210.html?DbPAR=CALC">Barre Aperçu</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0214.html?DbPAR=CALC">Barre Image</a></li>\
    <li><a target="_top" href="fr/text/scalc/main0218.html?DbPAR=CALC">Barre Outils</a></li>\
    <li><a target="_top" href="fr/text/shared/main0201.html?DbPAR=CALC">Barre Standard</a></li>\
    <li><a target="_top" href="fr/text/shared/main0212.html?DbPAR=CALC">Barre des données de la table</a></li>\
    <li><a target="_top" href="fr/text/shared/main0213.html?DbPAR=CALC">Barre Navigation pour formulaires</a></li>\
    <li><a target="_top" href="fr/text/shared/main0214.html?DbPAR=CALC">Barre Ébauche de requête</a></li>\
    <li><a target="_top" href="fr/text/shared/main0226.html?DbPAR=CALC">Barre Ébauche de formulaire</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">Types de fonctions et opérateurs</label><ul>\
    <li><a target="_top" href="fr/text/scalc/01/04060000.html?DbPAR=CALC">Assistant Fonction</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060100.html?DbPAR=CALC">Fonctions par catégorie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060107.html?DbPAR=CALC">Fonctions de matrice</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060120.html?DbPAR=CALC">Fonctions d&#39;opérations de bit</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060101.html?DbPAR=CALC">Fonctions de base de données</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060102.html?DbPAR=CALC">Fonctions de date et d&#39;heure</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060103.html?DbPAR=CALC">Fonctions financières - Première partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060119.html?DbPAR=CALC">Fonctions financières - Deuxième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060118.html?DbPAR=CALC">Fonctions financières - Troisième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060104.html?DbPAR=CALC">Fonctions d&#39;informations</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060105.html?DbPAR=CALC">Fonctions logiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060106.html?DbPAR=CALC">Fonctions mathématiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060108.html?DbPAR=CALC">Fonctions statistiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060181.html?DbPAR=CALC">Fonctions statistiques - Première partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060182.html?DbPAR=CALC">Fonctions statistiques - Deuxième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060183.html?DbPAR=CALC">Fonctions statistiques - Troisième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060184.html?DbPAR=CALC">Fonctions statistiques - Quatrième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060185.html?DbPAR=CALC">Fonctions statistiques - Cinquième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060109.html?DbPAR=CALC">Fonctions de classeur</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060110.html?DbPAR=CALC">Fonctions de texte</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060111.html?DbPAR=CALC">Fonctions des add-ins</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060115.html?DbPAR=CALC">Fonctions des add-ins/Liste des fonctions d&#39;analyse - Première partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060116.html?DbPAR=CALC">Fonctions des add-ins/Liste des fonctions d&#39;analyse - Deuxième partie</a></li>\
    <li><a target="_top" href="fr/text/scalc/01/04060199.html?DbPAR=CALC">Opérateurs dans LibreOffice Calc</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/userdefined_function.html?DbPAR=CALC">Fonctions définies par l&#39;utilisateur</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Chargement, enregistrement, import, export et caviardage</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/webquery.html?DbPAR=CALC">Insertion de données externes dans une table (requête Web)</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/html_doc.html?DbPAR=CALC">Ouverture et enregistrement de feuilles de calcul en HTML</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/csv_formula.html?DbPAR=CALC">Import et export de fichiers texte</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redaction.html?DbPAR=CALC">Caviardage</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">Formater</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/text_rotate.html?DbPAR=CALC">Rotation du texte</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/text_wrap.html?DbPAR=CALC">Rédaction de texte sur plusieurs lignes</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/text_numbers.html?DbPAR=CALC">Formatage des nombres en tant que texte</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/super_subscript.html?DbPAR=CALC">Texte en exposant ou en indice</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/row_height.html?DbPAR=CALC">Modification de la hauteur des lignes ou de la largeur des colonnes</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">Application du formatage conditionnel</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">Mise en évidence des nombres négatifs</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">Assignation de formats par une formule</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">Saisie d&#39;un nombre avec des zéros non significatifs</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/format_table.html?DbPAR=CALC">Formatage de classeurs</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/format_value.html?DbPAR=CALC">Formatage des nombres décimaux</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/value_with_name.html?DbPAR=CALC">Attribution d&#39;un nom aux cellules</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/table_rotate.html?DbPAR=CALC">Rotation de tables (transposition)</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/rename_table.html?DbPAR=CALC">Renommer des feuilles</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/year2000.html?DbPAR=CALC">Années 19xx/20xx</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">Utilisation de nombres arrondis</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/currency_format.html?DbPAR=CALC">Cellules au format monétaire</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/autoformat.html?DbPAR=CALC">Utilisation de l&#39;AutoFormat dans les tables</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/note_insert.html?DbPAR=CALC">Insertion et édition des commentaires</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/design.html?DbPAR=CALC">Sélection de thèmes pour les feuilles</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/fraction_enter.html?DbPAR=CALC">Saisir des fractions</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">Filtrer et trier</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/filters.html?DbPAR=CALC">Application de filtres</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/specialfilter.html?DbPAR=CALC">Filtre : application de filtres spéciaux</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/autofilter.html?DbPAR=CALC">Application de l&#39;AutoFiltre</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/sorted_list.html?DbPAR=CALC">Application de listes de tri</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">Imprimer</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/print_title_row.html?DbPAR=CALC">Impression de lignes ou de colonnes sur chaque page</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/print_landscape.html?DbPAR=CALC">Impression de feuilles au format paysage</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/print_details.html?DbPAR=CALC">Impression des détails de la feuille</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/print_exact.html?DbPAR=CALC">Définition du nombre de pages à imprimer</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">Plages de données</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/database_define.html?DbPAR=CALC">Définition de plages de base de données</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/database_filter.html?DbPAR=CALC">Filtrage des plages de cellules</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/database_sort.html?DbPAR=CALC">Trier des données</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">Table dynamique</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot.html?DbPAR=CALC">Table dynamique</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">Création de tables dynamiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">Suppression des tables dynamiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">Édition de tables dynamiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">Filtrage des tables dynamiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">Sélectionner des plages de sortie de table dynamique</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">Actualisation des tables dynamiques</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Diagramme dynamique</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/pivotchart.html?DbPAR=CALC">Diagramme de table dynamique</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Création de diagrammes de table dynamique.</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Édition des diagrammes de table dynamique</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtrage des diagrammes de table dynamique</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Actualiser un diagramme de table dynamique</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Suppression de diagrammes de table dynamique</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">Scénarios</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/scenario.html?DbPAR=CALC">Utilisation de scénarios</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">Références</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">Adresses et références absolues et relatives</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellreferences.html?DbPAR=CALC">Référencement d&#39;une cellule dans un autre document</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">Références à d&#39;autres feuilles et référencer des URL</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">Référencer des cellules par glisser-déposer</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/address_auto.html?DbPAR=CALC">Reconnaissance des noms comme adressage</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">Afficher, sélectionner, copier</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/table_view.html?DbPAR=CALC">Modification de l&#39;affichage des tables</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/formula_value.html?DbPAR=CALC">Affichage de formules ou de valeurs</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/line_fix.html?DbPAR=CALC">Fixation de lignes ou de colonnes en tant qu&#39;en-têtes</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/multi_tables.html?DbPAR=CALC">Navigation entre les onglets des feuilles</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/edit_multitables.html?DbPAR=CALC">Copie vers plusieurs feuilles</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cellcopy.html?DbPAR=CALC">Copier uniquement des cellules visibles</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/mark_cells.html?DbPAR=CALC">Sélection de plusieurs cellules</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">Formules et calculs</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/formulas.html?DbPAR=CALC">Calcul avec des formules</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/formula_copy.html?DbPAR=CALC">Copie des formules</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/formula_enter.html?DbPAR=CALC">Saisir des formules</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/formula_value.html?DbPAR=CALC">Affichage de formules ou de valeurs</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/calculate.html?DbPAR=CALC">Calcul dans les feuilles de calcul</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/calc_date.html?DbPAR=CALC">Calcul avec dates et heures</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/calc_series.html?DbPAR=CALC">Calcul automatique d&#39;une série</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">Calcul des différences entre les heures</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/matrixformula.html?DbPAR=CALC">Saisie de formules de matrice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">Protection</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/cell_protect.html?DbPAR=CALC">Protection des cellules contre les modifications</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">Annulation de la protection des cellules</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">Divers</label><ul>\
    <li><a target="_top" href="fr/text/scalc/guide/auto_off.html?DbPAR=CALC">Désactivation des modifications automatiques</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/consolidate.html?DbPAR=CALC">Consolidation des données</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/goalseek.html?DbPAR=CALC">Application de la recherche de valeur cible</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/multioperation.html?DbPAR=CALC">Application d&#39;opérations multiples</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/multitables.html?DbPAR=CALC">Application de plusieurs feuilles</a></li>\
    <li><a target="_top" href="fr/text/scalc/guide/validity.html?DbPAR=CALC">Validité du contenu des cellules</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">Graphiques et diagrammes</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">Informations générales</label><ul>\
    <li><a target="_top" href="fr/text/schart/main0000.html?DbPAR=CHART">Diagrammes dans LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/schart/main0503.html?DbPAR=CHART">Fonctionnalités de LibreOffice Chart</a></li>\
    <li><a target="_top" href="fr/text/schart/04/01020000.html?DbPAR=CHART">Raccourcis pour les diagrammes</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">Installation de LibreOffice</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Modification de l&#39;association des types de document Microsoft Office</a></li>\
    <li><a target="_top" href="fr/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Mode sans échec</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">Rubriques d&#39;aide communes</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">Informations générales</label><ul>\
    <li><a target="_top" href="fr/text/shared/main0400.html?DbPAR=SHARED">Raccourcis clavier</a></li>\
    <li><a target="_top" href="fr/text/shared/00/00000005.html?DbPAR=SHARED">Glossaire général</a></li>\
    <li><a target="_top" href="fr/text/shared/00/00000002.html?DbPAR=SHARED">Glossaires de termes Internet</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/accessibility.html?DbPAR=SHARED">Accessibilité dans LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/keyboard.html?DbPAR=SHARED">Raccourcis (accessibilité LibreOffice)</a></li>\
    <li><a target="_top" href="fr/text/shared/04/01010000.html?DbPAR=SHARED">Raccourcis clavier généraux dans LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/version_number.html?DbPAR=SHARED">Numéros de version et de compilation</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice et Microsoft Office</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/ms_user.html?DbPAR=SHARED">Utilisation de Microsoft Office et de LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">Comparaison des termes Microsoft Office et LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">À propos de la conversion des documents Microsoft Office</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">Modification de l&#39;association des types de document Microsoft Office</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">Options LibreOffice</label><ul>\
    <li><a target="_top" href="fr/text/shared/optionen/01000000.html?DbPAR=SHARED">Options</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010100.html?DbPAR=SHARED">Données d&#39;identité</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010200.html?DbPAR=SHARED">Général</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010300.html?DbPAR=SHARED">Chemins</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010400.html?DbPAR=SHARED">Linguistique</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010600.html?DbPAR=SHARED">Général</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010700.html?DbPAR=SHARED">Polices</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010800.html?DbPAR=SHARED">Affichage</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01010900.html?DbPAR=SHARED">Options d&#39;impression</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01012000.html?DbPAR=SHARED">Couleurs de l&#39;interface</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01013000.html?DbPAR=SHARED">Accessibilité</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/java.html?DbPAR=SHARED">Avancé</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Configuration avancée</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">EDI Basic</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01020000.html?DbPAR=SHARED">Options Chargement/enregistrement</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01030000.html?DbPAR=SHARED">Options Internet</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01040000.html?DbPAR=SHARED">Options de document texte</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01050000.html?DbPAR=SHARED">Options de document HTML</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01060000.html?DbPAR=SHARED">Options de classeur</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01070000.html?DbPAR=SHARED">Options de présentation</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01080000.html?DbPAR=SHARED">Options de dessin</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01090000.html?DbPAR=SHARED">Formule</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01110000.html?DbPAR=SHARED">Options des diagrammes</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01130100.html?DbPAR=SHARED">Propriétés VBA</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01140000.html?DbPAR=SHARED">Langues</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01150000.html?DbPAR=SHARED">Options de paramètres linguistiques</a></li>\
    <li><a target="_top" href="fr/text/shared/optionen/01160000.html?DbPAR=SHARED">Options de sources de données</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">Assistants</label><ul>\
    <li><a target="_top" href="fr/text/shared/autopi/01000000.html?DbPAR=SHARED">Assistant</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">Assistant lettre</label><ul>\
    <li><a target="_top" href="fr/text/shared/autopi/01010000.html?DbPAR=SHARED">Assistant Lettre</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">Assistant fax</label><ul>\
    <li><a target="_top" href="fr/text/shared/autopi/01020000.html?DbPAR=SHARED">Assistant Fax</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">Assistant agenda</label><ul>\
    <li><a target="_top" href="fr/text/shared/autopi/01040000.html?DbPAR=SHARED">Assistant Agenda</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">Assistant export HTML</label><ul>\
    <li><a target="_top" href="fr/text/shared/autopi/01110000.html?DbPAR=SHARED">Export HTML</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">Assistant convertisseur de documents</label><ul>\
    <li><a target="_top" href="fr/text/shared/autopi/01130000.html?DbPAR=SHARED">Convertisseur de documents</a></li>\
			</ul></li>\
    <li><a target="_top" href="fr/text/shared/autopi/01150000.html?DbPAR=SHARED">Assistant Euro-convertisseur</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">Configurer LibreOffice</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/configure_overview.html?DbPAR=SHARED">Configuration de LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/01/packagemanager.html?DbPAR=SHARED">Gestionnaire des extensions</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/flat_icons.html?DbPAR=SHARED">Modification de l&#39;affichage des icônes</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">Ajout de boutons aux barres d&#39;outils</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/workfolder.html?DbPAR=SHARED">Modifier le répertoire de travail</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/standard_template.html?DbPAR=SHARED">Modification des modèles par défaut</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_addressbook.html?DbPAR=SHARED">Enregistrement d&#39;un carnet d&#39;adresses</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/formfields.html?DbPAR=SHARED">Insertion et édition de boutons</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">Travailler avec l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">Navigation pour atteindre rapidement des objets</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/navigator.html?DbPAR=SHARED">Navigateur pour une vue d&#39;ensemble des documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/autohide.html?DbPAR=SHARED">Affichage, ancrage et masquage des fenêtres</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/textmode_change.html?DbPAR=SHARED">Basculement entre le mode Insertion et le mode Écrasement</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">Utilisation des barres d&#39;outils</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Signatures numériques</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/digital_signatures.html?DbPAR=SHARED">À propos des signatures numériques</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">Application de signatures numériques</a></li>\
    <li><a target="_top" href="fr/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">Export PDF de signature numérique</a></li>\
    <li><a target="_top" href="fr/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signature d&#39;un PDF existant</a></li>\
    <li><a target="_top" href="fr/text/swriter/01/addsignatureline.html?DbPAR=SHARED">Ajouter une ligne de signature dans les documents texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/01/signsignatureline.html?DbPAR=SHARED">Signer la ligne de signature</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">Imprimer, faxer, envoyer</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/labels_database.html?DbPAR=SHARED">Impression d&#39;étiquettes d&#39;adresses</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">Impression en noir et blanc</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/email.html?DbPAR=SHARED">Envoi de documents par e-mail</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/fax.html?DbPAR=SHARED">Envoi de fax et configuration de LibreOffice pour les fax</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">Glisser et déposer</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop.html?DbPAR=SHARED">Glisser-déposer dans un document LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">Déplacement et copie de texte dans des documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copie de zones de feuille de calcul vers des documents texte</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copie de graphiques entre différents documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copie d&#39;images à partir de la Galerie</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">Glisser-déposer avec la vue des sources de données</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">Copier et coller</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">Copie d&#39;objets de dessin dans d&#39;autres documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">Copie de graphiques entre différents documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">Copie d&#39;images à partir de la Galerie</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">Copie de zones de feuille de calcul vers des documents texte</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">Graphiques et diagrammes</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/chart_insert.html?DbPAR=SHARED">Insertion de diagrammes</a></li>\
    <li><a target="_top" href="fr/text/schart/main0000.html?DbPAR=SHARED">Diagrammes dans LibreOffice</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Charger, enregistrer, importer,  exporter, PDF</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/doc_open.html?DbPAR=SHARED">Ouverture de documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/import_ms.html?DbPAR=SHARED">Ouverture de documents enregistrés sous d&#39;autres formats</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/doc_save.html?DbPAR=SHARED">Enregistrement de documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/doc_autosave.html?DbPAR=SHARED">Enregistrement automatique des documents</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/export_ms.html?DbPAR=SHARED">Enregistrement de documents dans d&#39;autres formats</a></li>\
    <li><a target="_top" href="fr/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">Exporter au format PDF</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">Import et export de données au format texte</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">Liens et références</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">Insertion d&#39;hyperliens</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">Liens relatifs et absolus</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">Édition des hyperliens</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">Suivi de versions du document</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">Comparaison des versions d&#39;un document</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">Fusion des versions</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redlining_enter.html?DbPAR=SHARED">Enregistrement des modifications</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redlining.html?DbPAR=SHARED">Enregistrement et affichage des modifications</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redlining_accept.html?DbPAR=SHARED">Acceptation ou rejet des modifications</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redlining_versions.html?DbPAR=SHARED">Gestion de versions</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">Étiquettes et cartes de visite</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/labels.html?DbPAR=SHARED">Création et impression d&#39;étiquettes et de cartes de visite</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">Insérer des données externes</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/copytable2application.html?DbPAR=SHARED">Insertion de données à partir de classeurs</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/copytext2application.html?DbPAR=SHARED">Insertion de données à partir de documents texte</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">Insertion, édition, enregistrement de bitmaps</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">Ajout de graphiques à la galerie</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">Fonctions automatiques</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/autocorr_url.html?DbPAR=SHARED">Désactiver la détection automatique des URL</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">Rechercher et remplacer</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/data_search2.html?DbPAR=SHARED">Recherche à l&#39;aide d&#39;un filtre de formulaire</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_search.html?DbPAR=SHARED">Recherche dans des tables et des formulaires</a></li>\
    <li><a target="_top" href="fr/text/shared/01/02100001.html?DbPAR=SHARED">Liste des expressions régulières</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">Guides</label><ul>\
    <li><a target="_top" href="fr/text/shared/guide/linestyles.html?DbPAR=SHARED">Application de styles de ligne</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/text_color.html?DbPAR=SHARED">Modification de la couleur du texte</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/change_title.html?DbPAR=SHARED">Modification du titre d&#39;un document</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/round_corner.html?DbPAR=SHARED">Création d&#39;angles arrondis</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/background.html?DbPAR=SHARED">Définition de couleurs et d&#39;images d&#39;arrière-plan</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/lineend_define.html?DbPAR=SHARED">Définition d&#39;extrémités de ligne</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/linestyle_define.html?DbPAR=SHARED">Définition de styles de ligne</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">Éditer les objets graphiques</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/line_intext.html?DbPAR=SHARED">Lignes de dessin dans un texte</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/aaa_start.html?DbPAR=SHARED">Premiers pas</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/gallery_insert.html?DbPAR=SHARED">Insertion d&#39;objets depuis la Galerie</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Insertion d&#39;espaces insécables, de traits d&#39;union et traits d&#39;union conditionnels (césure)</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">Insertion de caractères spéciaux</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/tabs.html?DbPAR=SHARED">Insertion et modification des tabulations</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/protection.html?DbPAR=SHARED">Protection du contenu dans LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redlining_protect.html?DbPAR=SHARED">Protection de l&#39;historique</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/pageformat_max.html?DbPAR=SHARED">Sélection de la zone d&#39;impression maximale sur une page</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/measurement_units.html?DbPAR=SHARED">Sélection d&#39;unités de mesure</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/language_select.html?DbPAR=SHARED">Sélection de la langue du document</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">Ébauche de table...</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/numbering_stop.html?DbPAR=SHARED">Désactivation de la numérotation et des puces pour les paragraphes isolés</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Fonctions de base de données (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">Informations générales</label><ul>\
    <li><a target="_top" href="fr/text/shared/explorer/database/main.html?DbPAR=SHARED">Base de données LibreOffice</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/database_main.html?DbPAR=SHARED">Présentation des bases de données</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_new.html?DbPAR=SHARED">Création d&#39;une base de données</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_tables.html?DbPAR=SHARED">Utilisation des tables</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_queries.html?DbPAR=SHARED">Utilisation des requêtes</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_forms.html?DbPAR=SHARED">Utilisation des formulaires</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_reports.html?DbPAR=SHARED">Créer des rapports</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_register.html?DbPAR=SHARED">Enregistrer et supprimer une base de données</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_im_export.html?DbPAR=SHARED">Import et export de données dans Base</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/data_enter_sql.html?DbPAR=SHARED">Exécution d&#39;instructions SQL</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Présentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/simpress/main0000.html?DbPAR=IMPRESS">Bienvenue dans l&#39;aide de LibreOffice Impress</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0503.html?DbPAR=IMPRESS">Fonctionnalités de LibreOffice Impress</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">Utilisation de raccourcis clavier dans LibreOffice Impress</a></li>\
    <li><a target="_top" href="fr/text/simpress/04/01020000.html?DbPAR=IMPRESS">Raccourcis clavier dans LibreOffice Impress</a></li>\
    <li><a target="_top" href="fr/text/simpress/04/presenter.html?DbPAR=IMPRESS">Raccourcis clavier de la console de présentation</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/main.html?DbPAR=IMPRESS">Instructions d&#39;utilisation de LibreOffice Impress</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">Références des menus et des commandes</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">Menus</label><ul>\
    <li><a target="_top" href="fr/text/simpress/main0100.html?DbPAR=IMPRESS">Menus</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0101.html?DbPAR=IMPRESS">Fichier</a></li>\
    <li><a target="_top" href="fr/text/simpress/main_edit.html?DbPAR=IMPRESS">Édition</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0103.html?DbPAR=IMPRESS">Afficher</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0104.html?DbPAR=IMPRESS">Insérer</a></li>\
    <li><a target="_top" href="fr/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="fr/text/simpress/main_slide.html?DbPAR=IMPRESS">Diapo</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0114.html?DbPAR=IMPRESS">Diaporama</a></li>\
    <li><a target="_top" href="fr/text/simpress/main_tools.html?DbPAR=IMPRESS">Outils</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0107.html?DbPAR=IMPRESS">Fenêtre</a></li>\
    <li><a target="_top" href="fr/text/shared/main0108.html?DbPAR=IMPRESS">Aide</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">Barres d&#39;outils</label><ul>\
    <li><a target="_top" href="fr/text/simpress/main0200.html?DbPAR=IMPRESS">Barres d&#39;outils</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0202.html?DbPAR=IMPRESS">Barre Ligne et remplissage</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0203.html?DbPAR=IMPRESS">Barre Formatage de texte</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0204.html?DbPAR=IMPRESS">Barre Mode Diapo</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0206.html?DbPAR=IMPRESS">Barre d&#39;état</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0209.html?DbPAR=IMPRESS">Règles</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0210.html?DbPAR=IMPRESS">Barre Dessin</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0211.html?DbPAR=IMPRESS">Barre Plan</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0212.html?DbPAR=IMPRESS">Barre Trieuse de diapos</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0213.html?DbPAR=IMPRESS">Barre d&#39;options</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0214.html?DbPAR=IMPRESS">Barre Image</a></li>\
    <li><a target="_top" href="fr/text/shared/main0201.html?DbPAR=IMPRESS">Barre Standard</a></li>\
    <li><a target="_top" href="fr/text/shared/main0213.html?DbPAR=IMPRESS">Barre Navigation pour formulaires</a></li>\
    <li><a target="_top" href="fr/text/shared/main0226.html?DbPAR=IMPRESS">Barre Ébauche de formulaire</a></li>\
    <li><a target="_top" href="fr/text/shared/main0227.html?DbPAR=IMPRESS">Barre Éditer des points</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Chargement, enregistrement, import, export et caviardage</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/html_export.html?DbPAR=IMPRESS">Enregistrement d&#39;une présentation au format HTML</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/html_import.html?DbPAR=IMPRESS">Import de pages HTML dans les présentations</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Chargement de palettes de couleurs, dégradés et hachures</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Export d&#39;animations au format GIF</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Insertion de feuilles de calcul dans les diapos</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Insertion d&#39;images</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">Copie de diapos à partir d&#39;autres présentations</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redaction.html?DbPAR=IMPRESS">Caviardage</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">Formater</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">Chargement de palettes de couleurs, dégradés et hachures</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Chargement de styles de ligne et de flèche</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">Définition de couleurs personnalisées</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">Création de remplissages de dégradés</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">Remplacement de couleurs</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">Disposition, alignement et répartition des objets</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/background.html?DbPAR=IMPRESS">Modification du remplissage d&#39;arrière-plan de la diapo</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/footer.html?DbPAR=IMPRESS">Ajout d&#39;un en-tête ou d&#39;un pied de page à toutes les diapos</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Modifier et ajouter une page maîtresse</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Déplacement d&#39;objets</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">Imprimer</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/printing.html?DbPAR=IMPRESS">Impression de présentations</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">Impression d&#39;une diapo adaptée au format de papier</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">Effets</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">Export d&#39;animations au format GIF</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">Animation d&#39;objets dans un diaporama</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">Animation des transitions</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">Effectuer un fondu enchaîné de deux objets</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">Création d&#39;images GIF animées</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">Objets, images et bitmaps</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">Regroupement d&#39;objets et construction de formes</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/groups.html?DbPAR=IMPRESS">Groupement d&#39;objets</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">Dessins de secteurs et de segments</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">Duplication d&#39;objets</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">Rotation des objets</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">Assemblage d&#39;objets 3D</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">Connexion de lignes</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Conversion de caractères de texte en objets de dessin</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">Conversion d&#39;images Bitmap en images vectorielles</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">Conversion d&#39;objets 2D en courbes, polygones et objets 3D</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">Chargement de styles de ligne et de flèche</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">Dessin de courbes</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">Édition de courbes</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">Insertion d&#39;images</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">Insertion de feuilles de calcul dans les diapos</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/move_object.html?DbPAR=IMPRESS">Déplacement d&#39;objets</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/select_object.html?DbPAR=IMPRESS">Sélection d&#39;objets sous-jacents</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">Création d&#39;un organigramme</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Texte dans les présentations</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">Ajout de texte</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">Conversion de caractères de texte en objets de dessin</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">Afficher</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">Modification de l&#39;ordre des diapos</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">Zoom à l&#39;aide du pavé numérique</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">Diaporamas</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/show.html?DbPAR=IMPRESS">Affichage du diaporama</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Utilisation de la console de présentation</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Guide Impress Remote</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/individual.html?DbPAR=IMPRESS">Création d&#39;un diaporama personnalisé</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">Présentation chronométrée des changements de diapos</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formules (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/smath/main0000.html?DbPAR=MATH">Bienvenue dans l&#39;aide de LibreOffice Math</a></li>\
    <li><a target="_top" href="fr/text/smath/main0503.html?DbPAR=MATH">Fonctionnalités de LibreOffice Math</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">Éléments de formule LibreOffice</label><ul>\
    <li><a target="_top" href="fr/text/smath/01/03090100.html?DbPAR=MATH">Opérateurs unaires/binaires</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090200.html?DbPAR=MATH">Relations</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090800.html?DbPAR=MATH">Opérateurs d&#39;ensemble</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090400.html?DbPAR=MATH">Fonctions</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090300.html?DbPAR=MATH">Opérateurs</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090600.html?DbPAR=MATH">Attributs</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090500.html?DbPAR=MATH">Crochets</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03090700.html?DbPAR=MATH">Format</a></li>\
    <li><a target="_top" href="fr/text/smath/01/03091600.html?DbPAR=MATH">Autres symboles</a></li>\
            </ul></li>\
    <li><a target="_top" href="fr/text/smath/guide/main.html?DbPAR=MATH">Instructions d&#39;utilisation de LibreOffice Math</a></li>\
    <li><a target="_top" href="fr/text/smath/guide/keyboard.html?DbPAR=MATH">Raccourcis (accessibilité LibreOffice Math)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">Références des menus et des commandes</label><ul>\
    <li><a target="_top" href="fr/text/smath/main0100.html?DbPAR=MATH">Menus</a></li>\
    <li><a target="_top" href="fr/text/smath/main0200.html?DbPAR=MATH">Barres d&#39;outils</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">Travailler avec des formules</label><ul>\
    <li><a target="_top" href="fr/text/smath/guide/align.html?DbPAR=MATH">Alignement manuel des éléments d&#39;une formule</a></li>\
    <li><a target="_top" href="fr/text/smath/guide/attributes.html?DbPAR=MATH">Modification des attributs par défaut</a></li>\
    <li><a target="_top" href="fr/text/smath/guide/brackets.html?DbPAR=MATH">Fusion des éléments de la formule entre parenthèses</a></li>\
    <li><a target="_top" href="fr/text/smath/guide/comment.html?DbPAR=MATH">Saisie de commentaires</a></li>\
    <li><a target="_top" href="fr/text/smath/guide/newline.html?DbPAR=MATH">Insertion de retours à la ligne</a></li>\
    <li><a target="_top" href="fr/text/smath/guide/parentheses.html?DbPAR=MATH">Insertion de parenthèses</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="02"><label for="02">Documents texte (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/swriter/main0000.html?DbPAR=WRITER">Bienvenue dans l&#39;aide de LibreOffice Writer</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0503.html?DbPAR=WRITER">Fonctionnalités de LibreOffice Writer</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/main.html?DbPAR=WRITER">Instructions d&#39;utilisation de LibreOffice Writer</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">Ancrage et redimensionnement de fenêtres</a></li>\
    <li><a target="_top" href="fr/text/swriter/04/01020000.html?DbPAR=WRITER">Raccourcis clavier dans LibreOffice Writer</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/words_count.html?DbPAR=WRITER">Comptage des mots</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/keyboard.html?DbPAR=WRITER">Utilisation des raccourcis clavier (accessibilité dans LibreOffice Writer)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">Références des menus et des commandes</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">Menus</label><ul>\
    <li><a target="_top" href="fr/text/swriter/main0100.html?DbPAR=WRITER">Menus</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0101.html?DbPAR=WRITER">Fichier</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0102.html?DbPAR=WRITER">Éditer</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0103.html?DbPAR=WRITER">Afficher</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0104.html?DbPAR=WRITER">Insertion</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0105.html?DbPAR=WRITER">Format</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0115.html?DbPAR=WRITER">Styles</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0110.html?DbPAR=WRITER">Tableau</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0120.html?DbPAR=WRITER">Menu de formulaire</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0106.html?DbPAR=WRITER">Outils</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0107.html?DbPAR=WRITER">Fenêtre</a></li>\
    <li><a target="_top" href="fr/text/shared/main0108.html?DbPAR=WRITER">Aide</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">Barres d&#39;outils</label><ul>\
    <li><a target="_top" href="fr/text/swriter/main0200.html?DbPAR=WRITER">Barres d&#39;outils</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0202.html?DbPAR=WRITER">Barre Formatage</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0203.html?DbPAR=WRITER">Barre Image</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0204.html?DbPAR=WRITER">Barre Tableau</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0205.html?DbPAR=WRITER">Barre Propriétés de l&#39;objet de dessin</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0206.html?DbPAR=WRITER">Barre Puces et numérotation</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0208.html?DbPAR=WRITER">Barre d&#39;état</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0210.html?DbPAR=WRITER">Aperçu</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0213.html?DbPAR=WRITER">Règles</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0214.html?DbPAR=WRITER">Barre de formule</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0215.html?DbPAR=WRITER">Barre Cadre</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0216.html?DbPAR=WRITER">Barre Objets OLE</a></li>\
    <li><a target="_top" href="fr/text/swriter/main0220.html?DbPAR=WRITER">Barre Objet de texte</a></li>\
    <li><a target="_top" href="fr/text/shared/main0201.html?DbPAR=WRITER">Barre Standard</a></li>\
    <li><a target="_top" href="fr/text/shared/main0212.html?DbPAR=WRITER">Barre des données de la table</a></li>\
    <li><a target="_top" href="fr/text/shared/main0213.html?DbPAR=WRITER">Barre Navigation pour formulaires</a></li>\
    <li><a target="_top" href="fr/text/shared/main0214.html?DbPAR=WRITER">Barre Ébauche de requête</a></li>\
    <li><a target="_top" href="fr/text/shared/main0226.html?DbPAR=WRITER">Barre Ébauche de formulaire</a></li>\
    <li><a target="_top" href="fr/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">Barre d&#39;outils LibreLogo</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">Créer des documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">Navigation et sélection à l&#39;aide du clavier</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">Utilisation du curseur direct</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">Images dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">Insertion d&#39;images</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">Insertion d&#39;une image à partir d&#39;un fichier</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">Insertion d&#39;images depuis la Galerie par glisser-déposer</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">Insertion d&#39;une image lue au scanner</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">Insertion d&#39;un diagramme Calc dans un document texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">Insertion d&#39;images à partir de LibreOffice Draw ou Impress</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">Tableaux dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Activation et désactivation de la reconnaissance des nombres dans les tableaux</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/tablemode.html?DbPAR=WRITER">Modification des lignes et des colonnes à l&#39;aide du clavier</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/table_delete.html?DbPAR=WRITER">Suppression d&#39;un tableau ou de son contenu</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/table_insert.html?DbPAR=WRITER">Insertion de tableaux</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">Répétition d&#39;un en-tête d&#39;un tableau sur une nouvelle page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/table_sizing.html?DbPAR=WRITER">Redimensionnement de lignes et de colonnes dans un tableau texte</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">Objets dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/anchor_object.html?DbPAR=WRITER">Positionnement des objets</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/wrap.html?DbPAR=WRITER">Habillage autour des objets</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">Sections et cadres dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/sections.html?DbPAR=WRITER">Utilisation de sections</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_frame.html?DbPAR=WRITER">Insertion, édition et enchaînement de cadres</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/section_edit.html?DbPAR=WRITER">Édition de sections</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/section_insert.html?DbPAR=WRITER">Insérer des sections</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">Tables des matières et index</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numérotation des chapitres</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">Index personnalisés</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_toc.html?DbPAR=WRITER">Création d&#39;une table des matières</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_index.html?DbPAR=WRITER">Création d&#39;un index lexical</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">Index couvrant plusieurs documents</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_literature.html?DbPAR=WRITER">Création d&#39;une bibliographie</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_delete.html?DbPAR=WRITER">Édition et suppression d&#39;entrées d&#39;index ou de table des matières</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_edit.html?DbPAR=WRITER">Actualisation, édition et suppression d&#39;index et de tables des matières</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_enter.html?DbPAR=WRITER">Définition d&#39;entrées d&#39;index ou de table des matières</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/indices_form.html?DbPAR=WRITER">Formatage d&#39;un index ou d&#39;une table des matières</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">Champs dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/fields.html?DbPAR=WRITER">À propos des champs</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/fields_date.html?DbPAR=WRITER">Insertion d&#39;un champ de date fixe ou variable</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/field_convert.html?DbPAR=WRITER">Conversion d&#39;un champ en texte</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">Naviguer dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">Déplacement et copie de texte dans des documents</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">Réorganisation d&#39;un document à l&#39;aide du Navigateur</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Insertion d&#39;hyperliens à l&#39;aide du Navigateur</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/navigator.html?DbPAR=WRITER">Navigateur pour les documents texte</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">Calculer dans les documents texte</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">Calcul dans plusieurs tableaux</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/calculate.html?DbPAR=WRITER">Calcul dans les documents texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">Calcul d&#39;une formule et collage du résultat dans un document texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">Calcul de totaux dans les cellules de tableaux</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">Calcul de formules complexes dans des documents texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">Affichage du résultat d&#39;un calcul de tableau dans un autre tableau</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">Formater les documents texte</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">Modèles et styles</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/templates_styles.html?DbPAR=WRITER">Modèles et styles</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">Alternance des styles de page sur les pages paires et impaires</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/change_header.html?DbPAR=WRITER">Création d&#39;un style de page à partir de la page active</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/load_styles.html?DbPAR=WRITER">Utilisation de styles provenant d&#39;un autre document ou modèle</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">Création de styles à partir de sélections</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/stylist_update.html?DbPAR=WRITER">Actualisation de styles à partir de sélections</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/template_create.html?DbPAR=WRITER">Création d&#39;un modèle de document</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/template_default.html?DbPAR=WRITER">Changement de modèle par défaut</a></li>\
			</ul></li>\
    <li><a target="_top" href="fr/text/swriter/guide/pageorientation.html?DbPAR=WRITER">Modification de l&#39;orientation de la page (Paysage ou Portrait)</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_capital.html?DbPAR=WRITER">Modification de la casse du texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Masquage du texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Définition d&#39;en-têtes et de pieds de page différents</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Insertion du nom et du numéro de chapitre dans un en-tête ou un pied de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">Application d&#39;un formatage de texte pendant la saisie</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/reset_format.html?DbPAR=WRITER">Rétablissement des attributs de caractères</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">Application de styles en mode Tout remplir</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/wrap.html?DbPAR=WRITER">Habillage autour des objets</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_centervert.html?DbPAR=WRITER">Utilisation d&#39;un cadre pour centrer le texte sur la page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">Accentuation du texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_rotate.html?DbPAR=WRITER">Rotation du texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/page_break.html?DbPAR=WRITER">Insertion et suppression de sauts de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Création et application des styles de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/subscript.html?DbPAR=WRITER">Mise en exposant ou en indice d&#39;un texte</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">Éléments de texte spéciaux</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/captions.html?DbPAR=WRITER">Utilisation de légendes</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/conditional_text.html?DbPAR=WRITER">Texte conditionnel</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">Texte conditionnel pour le nombre de pages</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/fields_date.html?DbPAR=WRITER">Insertion d&#39;un champ de date fixe ou variable</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/fields_enter.html?DbPAR=WRITER">Ajout de champs de saisie</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">Insertion de numéros dans les pages suivantes</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">Insertion de numéros de page dans les pieds de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/hidden_text.html?DbPAR=WRITER">Masquage du texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">Définition d&#39;en-têtes et de pieds de page différents</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">Insertion du nom et du numéro de chapitre dans un en-tête ou un pied de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">Requête de données d&#39;utilisateur dans des champs ou des conditions</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">Insertion et édition de notes de bas de page et de notes de fin</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">Espacement entre les notes de bas de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/header_footer.html?DbPAR=WRITER">À propos des en-têtes et pieds de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/header_with_line.html?DbPAR=WRITER">Formatage des en-têtes et pieds de page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/text_animation.html?DbPAR=WRITER">Animation de texte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">Création d&#39;une lettre type</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">Fonctions automatiques</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">Ajout d&#39;exceptions à la liste d&#39;AutoCorrection</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/autotext.html?DbPAR=WRITER">Utilisation de la fonction AutoTexte</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Création de listes numérotées ou à puces lors de la saisie</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/auto_off.html?DbPAR=WRITER">Désactiver l&#39;AutoCorrection</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Vérification automatique de l&#39;orthographe</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">Activation et désactivation de la reconnaissance des nombres dans les tableaux</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">Coupure des mots</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">Numérotations et listes</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">Ajout de numéros de chapitres aux légendes</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">Création de listes numérotées ou à puces lors de la saisie</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Numérotation des chapitres</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Modification du niveau de plan des listes numérotées et des listes à puces</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">Combinaison de listes numérotées</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">Ajout de numéros de ligne</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">Modification de la numérotation d&#39;une liste numérotée</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/number_sequence.html?DbPAR=WRITER">Définition de séquences</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">Ajout d&#39;une numérotation</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/using_numbering.html?DbPAR=WRITER">Numérotation et styles de numérotation</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">Ajout de puces</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">Correcteurs, dictionnaire des synonymes et langues</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">Vérification automatique de l&#39;orthographe</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">Suppression de mots dans un dictionnaire de l&#39;utilisateur</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">Dictionnaire des synonymes</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">Vérification de l&#39;orthographe et de la grammaire</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">Astuces de dépannage</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">Insertion de texte avant un tableau situé en haut d&#39;une page</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">Positionner le curseur sur un repère de texte spécifique</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Charger, enregistrer, importer, exporter et caviarder</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/send2html.html?DbPAR=WRITER">Enregistrement de documents texte au format HTML</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">Insertion d&#39;un document texte entier</a></li>\
    <li><a target="_top" href="fr/text/shared/guide/redaction.html?DbPAR=WRITER">Caviardage</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">Documents maîtres</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/globaldoc.html?DbPAR=WRITER">Documents maîtres et sous-documents</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">Liens et références</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/references.html?DbPAR=WRITER">Insertion de renvois</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">Insertion d&#39;hyperliens à l&#39;aide du Navigateur</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">Imprimer</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/printer_tray.html?DbPAR=WRITER">Sélection des bacs d&#39;alimentation d&#39;imprimante</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/print_preview.html?DbPAR=WRITER">Aperçu de la page avant l&#39;impression</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/print_small.html?DbPAR=WRITER">Impression de plusieurs pages sur une feuille</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/pagestyles.html?DbPAR=WRITER">Création et application des styles de page</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">Rechercher et remplacer</label><ul>\
    <li><a target="_top" href="fr/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Utiliser des expressions régulières dans les recherches textuelles</a></li>\
    <li><a target="_top" href="fr/text/shared/01/02100001.html?DbPAR=WRITER">Liste des expressions régulières</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">Documents HTML (Writer Web)</label><ul>\
    <li><a target="_top" href="fr/text/shared/07/09000000.html?DbPAR=WRITER">Pages Web</a></li>\
    <li><a target="_top" href="fr/text/shared/02/01170700.html?DbPAR=WRITER">Filtres et formulaires HTML</a></li>\
    <li><a target="_top" href="fr/text/swriter/guide/send2html.html?DbPAR=WRITER">Enregistrement de documents texte au format HTML</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Dessins (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">Informations générales et utilisation de l&#39;interface utilisateur</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/main0000.html?DbPAR=DRAW">Bienvenue dans l&#39;aide de LibreOffice Draw</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main0503.html?DbPAR=DRAW">Fonctionnalités de LibreOffice Draw</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/keyboard.html?DbPAR=DRAW">Raccourcis claviers pour les objets de dessin</a></li>\
    <li><a target="_top" href="fr/text/sdraw/04/01020000.html?DbPAR=DRAW">Raccourcis clavier dans les dessins</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/main.html?DbPAR=DRAW">Instructions d&#39;utilisation de LibreOffice Draw</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Références des menus et des commandes</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/main0100.html?DbPAR=DRAW">Menus</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main0101.html?DbPAR=DRAW">Fichier</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main_edit.html?DbPAR=DRAW">Édition</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main0103.html?DbPAR=DRAW">Affichage</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main_insert.html?DbPAR=DRAW">Insérer</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main_shape.html?DbPAR=DRAW">Forme</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main_tools.html?DbPAR=DRAW">Outils</a></li>\
    <li><a target="_top" href="fr/text/simpress/main0107.html?DbPAR=DRAW">Fenêtre</a></li>\
    <li><a target="_top" href="fr/text/shared/main0108.html?DbPAR=DRAW">Aide</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Barre d&#39;outils</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/main0200.html?DbPAR=DRAW">Barres d&#39;outils</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main0210.html?DbPAR=DRAW">Barre de dessin</a></li>\
    <li><a target="_top" href="fr/text/sdraw/main0213.html?DbPAR=DRAW">Barre Options</a></li>\
    <li><a target="_top" href="fr/text/shared/main0201.html?DbPAR=DRAW">Barre Standard</a></li>\
    <li><a target="_top" href="fr/text/shared/main0213.html?DbPAR=DRAW">Barre Navigation pour formulaires</a></li>\
    <li><a target="_top" href="fr/text/shared/main0226.html?DbPAR=DRAW">Barre Ébauche de formulaire</a></li>\
    <li><a target="_top" href="fr/text/shared/main0227.html?DbPAR=DRAW">Barre Éditer des points</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Charger, enregistrer, importer et exporter</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/palette_files.html?DbPAR=DRAW">Chargement de palettes de couleurs, dégradés et hachures</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Insertion d&#39;images</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatage</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/palette_files.html?DbPAR=DRAW">Chargement de palettes de couleurs, dégradés et hachures</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Chargement de styles de ligne et de flèche</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/color_define.html?DbPAR=DRAW">Définition de couleurs personnalisées</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/gradient.html?DbPAR=DRAW">Création de remplissages de dégradés</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">Remplacement de couleurs</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">Disposition, alignement et répartition des objets</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/background.html?DbPAR=DRAW">Modification du remplissage d&#39;arrière-plan de la diapo</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/masterpage.html?DbPAR=DRAW">Modifier et ajouter une page maîtresse</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/move_object.html?DbPAR=DRAW">Déplacement d&#39;objets</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Impression</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/printing.html?DbPAR=DRAW">Impression de présentations</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/print_tofit.html?DbPAR=DRAW">Impression d&#39;une diapo adaptée au format de papier</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effets</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">Effectuer un fondu enchaîné de deux objets</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objets, images et bitmaps</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">Regroupement d&#39;objets et construction de formes</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">Dessins de secteurs et de segments</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">Duplication d&#39;objets</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">Rotation des objets</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">Assemblage d&#39;objets 3D</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/join_objects.html?DbPAR=DRAW">Connexion de lignes</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/text2curve.html?DbPAR=DRAW">Conversion de caractères de texte en objets de dessin</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/vectorize.html?DbPAR=DRAW">Conversion d&#39;images Bitmap en images vectorielles</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/3d_create.html?DbPAR=DRAW">Conversion d&#39;objets 2D en courbes, polygones et objets 3D</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">Chargement de styles de ligne et de flèche</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_draw.html?DbPAR=DRAW">Dessin de courbes</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/line_edit.html?DbPAR=DRAW">Édition de courbes</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">Insertion d&#39;images</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/table_insert.html?DbPAR=DRAW">Insertion de feuilles de calcul dans les diapos</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/move_object.html?DbPAR=DRAW">Déplacement d&#39;objets</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/select_object.html?DbPAR=DRAW">Sélection d&#39;objets sous-jacents</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/orgchart.html?DbPAR=DRAW">Création d&#39;un organigramme</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groupes et couches</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/guide/groups.html?DbPAR=DRAW">Groupement d&#39;objets</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/layers.html?DbPAR=DRAW">À propos des couches</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Insérer des couches</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Travailler avec des couches</a></li>\
    <li><a target="_top" href="fr/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Déplacer les objets sur une couche différente</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Texte dans les dessins</label><ul>\
    <li><a target="_top" href="fr/text/sdraw/guide/text_enter.html?DbPAR=DRAW">Ajout de texte</a></li>\
    <li><a target="_top" href="fr/text/simpress/guide/text2curve.html?DbPAR=DRAW">Conversion de caractères de texte en objets de dessin</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Affichage</label><ul>\
    <li><a target="_top" href="fr/text/simpress/guide/change_scale.html?DbPAR=DRAW">Zoom à l&#39;aide du pavé numérique</a></li>\
         </ul></li>\
     </ul></li></ul>\
';
