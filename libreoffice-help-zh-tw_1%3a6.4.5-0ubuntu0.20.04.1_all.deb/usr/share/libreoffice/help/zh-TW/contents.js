document.getElementById("Contents").innerHTML='\
    <ul><li><input type="checkbox" id="07"><label for="07">巨集及指令稿撰寫</label><ul>\
    <li><input type="checkbox" id="0701"><label for="0701">LibreOffice BASIC</label><ul>\
    <li><input type="checkbox" id="070101"><label for="070101">一般資訊及使用者介面用法</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/main0601.html?DbPAR=BASIC">LibreOffice Basic 說明</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01000000.html?DbPAR=BASIC">使用 LibreOffice Basic 進行程式設計</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/00000002.html?DbPAR=BASIC">LibreOffice Basic 詞彙表</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01010210.html?DbPAR=BASIC">LibreOffice Basic 具有模組化結構</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01020000.html?DbPAR=BASIC">語法</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01050000.html?DbPAR=BASIC">LibreOffice Basic IDE</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01030100.html?DbPAR=BASIC">IDE 摘要</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01030200.html?DbPAR=BASIC">Basic 編輯器</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01050100.html?DbPAR=BASIC">[檢視]視窗</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/main0211.html?DbPAR=BASIC">巨集工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/05060700.html?DbPAR=BASIC">巨集</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/vbasupport.html?DbPAR=BASIC">Support for VBA Macros</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070102"><label for="070102">Command Reference</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01020300.html?DbPAR=BASIC">使用程序和函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01020500.html?DbPAR=BASIC">程式庫、模組和對話方塊</a></li>\
    <li><input type="checkbox" id="07010202"><label for="07010202">Functions, Statements, and Operators</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010000.html?DbPAR=BASIC">螢幕 I/O 函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020000.html?DbPAR=BASIC">檔案 I/O 函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030000.html?DbPAR=BASIC">日期和時間函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03050000.html?DbPAR=BASIC">錯誤處理函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060000.html?DbPAR=BASIC">邏輯運算子</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070000.html?DbPAR=BASIC">數學運算子</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080000.html?DbPAR=BASIC">數值型函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090000.html?DbPAR=BASIC">控制程式的執行</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100000.html?DbPAR=BASIC">變數</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03040000.html?DbPAR=BASIC">Basic Constants</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03110000.html?DbPAR=BASIC">比較運算子</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120000.html?DbPAR=BASIC">字串</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/uno_objects.html?DbPAR=BASIC">UNO Objects</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/special_vba_func.html?DbPAR=BASIC">Exclusive VBA functions</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130000.html?DbPAR=BASIC">其他指令</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010201"><label for="07010201">Alphabetic List of Functions, Statements, and Operators</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080601.html?DbPAR=BASIC">Abs Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060100.html?DbPAR=BASIC">AND Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104200.html?DbPAR=BASIC">Array Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120101.html?DbPAR=BASIC">Asc Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120111.html?DbPAR=BASIC">AscW Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080101.html?DbPAR=BASIC">Atn Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130100.html?DbPAR=BASIC">Beep Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010301.html?DbPAR=BASIC">Blue Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100100.html?DbPAR=BASIC">CBool Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120105.html?DbPAR=BASIC">CByte Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100050.html?DbPAR=BASIC">CCur Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030116.html?DbPAR=BASIC">CDateFromUnoDateTime Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030115.html?DbPAR=BASIC">CDateToUnoDateTime Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030114.html?DbPAR=BASIC">CDateFromUnoTime Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030113.html?DbPAR=BASIC">CDateToUnoTime Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030112.html?DbPAR=BASIC">CDateFromUnoDate Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030111.html?DbPAR=BASIC">CDateToUnoDate Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030108.html?DbPAR=BASIC">CDateFromIso Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030107.html?DbPAR=BASIC">CDateToIso Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100300.html?DbPAR=BASIC">CDate Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100400.html?DbPAR=BASIC">CDbl Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100060.html?DbPAR=BASIC">CDec Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100500.html?DbPAR=BASIC">CInt Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100600.html?DbPAR=BASIC">CLng Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100900.html?DbPAR=BASIC">CSng Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101000.html?DbPAR=BASIC">CStr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090401.html?DbPAR=BASIC">Call Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020401.html?DbPAR=BASIC">ChDir Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020402.html?DbPAR=BASIC">ChDrive Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090402.html?DbPAR=BASIC">Choose Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120102.html?DbPAR=BASIC">Chr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120112.html?DbPAR=BASIC">ChrW Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020101.html?DbPAR=BASIC">Close Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100700.html?DbPAR=BASIC">Const Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120313.html?DbPAR=BASIC">ConvertFromURL Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120312.html?DbPAR=BASIC">ConvertToURL Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080102.html?DbPAR=BASIC">Cos Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03132400.html?DbPAR=BASIC">CreateObject Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131800.html?DbPAR=BASIC">CreateUnoDialog Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03132000.html?DbPAR=BASIC">CreateUnoListener Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131600.html?DbPAR=BASIC">CreateUnoService Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131500.html?DbPAR=BASIC">CreateUnoStruct Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03132300.html?DbPAR=BASIC">CreateUnoValue Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020403.html?DbPAR=BASIC">CurDir Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100070.html?DbPAR=BASIC">CVar Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03100080.html?DbPAR=BASIC">CVErr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030110.html?DbPAR=BASIC">DateAdd Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030120.html?DbPAR=BASIC">DateDiff Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030130.html?DbPAR=BASIC">DatePart Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030101.html?DbPAR=BASIC">DateSerial Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030102.html?DbPAR=BASIC">DateValue Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030301.html?DbPAR=BASIC">Date Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030103.html?DbPAR=BASIC">Day Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140000.html?DbPAR=BASIC">DDB Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090403.html?DbPAR=BASIC">Declare Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101100.html?DbPAR=BASIC">DefBool Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101300.html?DbPAR=BASIC">DefDate Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101400.html?DbPAR=BASIC">DefDbl Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101500.html?DbPAR=BASIC">DefInt Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101600.html?DbPAR=BASIC">DefLng Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03101700.html?DbPAR=BASIC">DefObj Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102000.html?DbPAR=BASIC">DefVar Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104300.html?DbPAR=BASIC">DimArray Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102100.html?DbPAR=BASIC">Dim Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020404.html?DbPAR=BASIC">Dir Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090201.html?DbPAR=BASIC">Do...Loop Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03110100.html?DbPAR=BASIC">Comparison Operators</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090404.html?DbPAR=BASIC">End Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/enum.html?DbPAR=BASIC">Enum Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130800.html?DbPAR=BASIC">Environ Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020301.html?DbPAR=BASIC">Eof Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104600.html?DbPAR=BASIC">EqualUnoObjects Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060200.html?DbPAR=BASIC">Eqv Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03050100.html?DbPAR=BASIC">Erl Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03050200.html?DbPAR=BASIC">Err Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03050300.html?DbPAR=BASIC">Error Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03050000.html?DbPAR=BASIC">錯誤處理函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090412.html?DbPAR=BASIC">Exit Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080201.html?DbPAR=BASIC">Exp Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020405.html?DbPAR=BASIC">FileAttr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020406.html?DbPAR=BASIC">FileCopy Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020407.html?DbPAR=BASIC">FileDateTime Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020415.html?DbPAR=BASIC">FileExists Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020408.html?DbPAR=BASIC">FileLen Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103800.html?DbPAR=BASIC">FindObject Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103900.html?DbPAR=BASIC">FindPropertyObject Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080501.html?DbPAR=BASIC">Fix Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090202.html?DbPAR=BASIC">For...Next Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120301.html?DbPAR=BASIC">Format Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03150000.html?DbPAR=BASIC">FormatDateTime Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03170010.html?DbPAR=BASIC">FormatNumber Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080503.html?DbPAR=BASIC">Frac Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020102.html?DbPAR=BASIC">FreeFile Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090405.html?DbPAR=BASIC">FreeLibrary Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090406.html?DbPAR=BASIC">Function Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090400.html?DbPAR=BASIC">其他陳述式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140001.html?DbPAR=BASIC">FV Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080300.html?DbPAR=BASIC">產生隨機數</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020409.html?DbPAR=BASIC">GetAttr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03132500.html?DbPAR=BASIC">GetDefaultContext Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03132100.html?DbPAR=BASIC">GetGuiType Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131700.html?DbPAR=BASIC">GetProcessServiceManager Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/GetPathSeparator.html?DbPAR=BASIC">GetPathSeparator function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131000.html?DbPAR=BASIC">GetSolarVersion Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130700.html?DbPAR=BASIC">GetSystemTicks Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020201.html?DbPAR=BASIC">Get Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131900.html?DbPAR=BASIC">GlobalScope</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090301.html?DbPAR=BASIC">GoSub...Return Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090302.html?DbPAR=BASIC">GoTo Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010302.html?DbPAR=BASIC">Green Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104400.html?DbPAR=BASIC">HasUnoInterfaces Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080801.html?DbPAR=BASIC">Hex Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030201.html?DbPAR=BASIC">Hour Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090103.html?DbPAR=BASIC">IIf Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090101.html?DbPAR=BASIC">If...Then...Else Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060300.html?DbPAR=BASIC">Imp Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120401.html?DbPAR=BASIC">InStr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120411.html?DbPAR=BASIC">InStrRev Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03160000.html?DbPAR=BASIC">Input Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010201.html?DbPAR=BASIC">InputBox Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020202.html?DbPAR=BASIC">Input# Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080502.html?DbPAR=BASIC">Int Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140002.html?DbPAR=BASIC">IPmt Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140003.html?DbPAR=BASIC">IRR Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102200.html?DbPAR=BASIC">IsArray Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102300.html?DbPAR=BASIC">IsDate Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102400.html?DbPAR=BASIC">IsEmpty Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104000.html?DbPAR=BASIC">IsMissing function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102600.html?DbPAR=BASIC">IsNull Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102700.html?DbPAR=BASIC">IsNumeric Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102800.html?DbPAR=BASIC">IsObject Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104500.html?DbPAR=BASIC">IsUnoStruct Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120315.html?DbPAR=BASIC">Join Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020410.html?DbPAR=BASIC">Kill Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102900.html?DbPAR=BASIC">LBound Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120302.html?DbPAR=BASIC">LCase Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120304.html?DbPAR=BASIC">LSet Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120305.html?DbPAR=BASIC">LTrim Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120303.html?DbPAR=BASIC">Left Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120402.html?DbPAR=BASIC">Len Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103100.html?DbPAR=BASIC">Let Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020203.html?DbPAR=BASIC">Line Input # Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020302.html?DbPAR=BASIC">Loc Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020303.html?DbPAR=BASIC">Lof Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080202.html?DbPAR=BASIC">Log Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120306.html?DbPAR=BASIC">Mid Function, Mid Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030202.html?DbPAR=BASIC">Minute Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140004.html?DbPAR=BASIC">MIRR Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020411.html?DbPAR=BASIC">MkDir Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070600.html?DbPAR=BASIC">Mod Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030104.html?DbPAR=BASIC">Month Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03150002.html?DbPAR=BASIC">MonthName Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010102.html?DbPAR=BASIC">MsgBox Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010101.html?DbPAR=BASIC">MsgBox Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020412.html?DbPAR=BASIC">Name Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060400.html?DbPAR=BASIC">Not Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030203.html?DbPAR=BASIC">Now Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140005.html?DbPAR=BASIC">NPer Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140006.html?DbPAR=BASIC">NPV Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080000.html?DbPAR=BASIC">數值型函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080802.html?DbPAR=BASIC">Oct Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03050500.html?DbPAR=BASIC">On Error GoTo ... Resume Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090303.html?DbPAR=BASIC">On...GoSub Statement; On...GoTo Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020103.html?DbPAR=BASIC">Open Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103200.html?DbPAR=BASIC">Option Base Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/classmodule.html?DbPAR=BASIC">Option ClassModule</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/compatible.html?DbPAR=BASIC">Option Compatible</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103300.html?DbPAR=BASIC">Option Explicit Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103350.html?DbPAR=BASIC">Option VBASupport Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03104100.html?DbPAR=BASIC">Optional (in Function Statement)</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060500.html?DbPAR=BASIC">Or Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/partition.html?DbPAR=BASIC">Partition Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140007.html?DbPAR=BASIC">Pmt Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140008.html?DbPAR=BASIC">PPmt Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140009.html?DbPAR=BASIC">PV Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010103.html?DbPAR=BASIC">Print Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103400.html?DbPAR=BASIC">Public Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020204.html?DbPAR=BASIC">Put Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010304.html?DbPAR=BASIC">QBColor Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140010.html?DbPAR=BASIC">Rate Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010305.html?DbPAR=BASIC">RGB Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120308.html?DbPAR=BASIC">RSet Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120309.html?DbPAR=BASIC">RTrim Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080301.html?DbPAR=BASIC">Randomize Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03102101.html?DbPAR=BASIC">ReDim Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03010303.html?DbPAR=BASIC">Red Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090407.html?DbPAR=BASIC">Rem Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/replace.html?DbPAR=BASIC">Replace Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020104.html?DbPAR=BASIC">Reset Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120307.html?DbPAR=BASIC">Right Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020413.html?DbPAR=BASIC">RmDir Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080302.html?DbPAR=BASIC">Rnd Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03170000.html?DbPAR=BASIC">Round Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030204.html?DbPAR=BASIC">Second Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020304.html?DbPAR=BASIC">Seek Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020305.html?DbPAR=BASIC">Seek Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090102.html?DbPAR=BASIC">Select...Case Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020414.html?DbPAR=BASIC">SetAttr Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103700.html?DbPAR=BASIC">Set Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080701.html?DbPAR=BASIC">Sgn Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130500.html?DbPAR=BASIC">Shell Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080103.html?DbPAR=BASIC">Sin Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140011.html?DbPAR=BASIC">SLN Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120201.html?DbPAR=BASIC">Space and Spc Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120314.html?DbPAR=BASIC">Split Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080401.html?DbPAR=BASIC">Sqr Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080400.html?DbPAR=BASIC">平方根的計算</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/stardesktop.html?DbPAR=BASIC">StarDesktop object</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103500.html?DbPAR=BASIC">Static Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090408.html?DbPAR=BASIC">Stop Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120403.html?DbPAR=BASIC">StrComp Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120103.html?DbPAR=BASIC">Str Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120412.html?DbPAR=BASIC">StrReverse Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120202.html?DbPAR=BASIC">String Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090409.html?DbPAR=BASIC">Sub Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090410.html?DbPAR=BASIC">Switch Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03140012.html?DbPAR=BASIC">SYD Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080104.html?DbPAR=BASIC">Tan Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03132200.html?DbPAR=BASIC">ThisComponent Object</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030205.html?DbPAR=BASIC">TimeSerial Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030206.html?DbPAR=BASIC">TimeValue Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030302.html?DbPAR=BASIC">Time Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030303.html?DbPAR=BASIC">Timer Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03080100.html?DbPAR=BASIC">三角函式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120311.html?DbPAR=BASIC">Trim Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131300.html?DbPAR=BASIC">TwipsPerPixelX Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03131400.html?DbPAR=BASIC">TwipsPerPixelY Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090413.html?DbPAR=BASIC">Type Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103600.html?DbPAR=BASIC">TypeName Function; VarType Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03103000.html?DbPAR=BASIC">UBound Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120310.html?DbPAR=BASIC">UCase Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03120104.html?DbPAR=BASIC">Val Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130600.html?DbPAR=BASIC">Wait Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03130610.html?DbPAR=BASIC">WaitUntil Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030105.html?DbPAR=BASIC">WeekDay Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03150001.html?DbPAR=BASIC">WeekdayName Function [VBA]</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090203.html?DbPAR=BASIC">While...Wend Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03090411.html?DbPAR=BASIC">With Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03020205.html?DbPAR=BASIC">Write Statement</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03060600.html?DbPAR=BASIC">XOR Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03030106.html?DbPAR=BASIC">Year Function</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070100.html?DbPAR=BASIC">"-" Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070200.html?DbPAR=BASIC">"*" Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070300.html?DbPAR=BASIC">"+" Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070400.html?DbPAR=BASIC">"/" Operator</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03070500.html?DbPAR=BASIC">"^" Operator</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="07010205"><label for="07010205">Advanced Basic Libraries</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_tools.html?DbPAR=BASIC">Tools Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_depot.html?DbPAR=BASIC">DEPOT Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_euro.html?DbPAR=BASIC">EURO Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_formwizard.html?DbPAR=BASIC">FORMWIZARD Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_gimmicks.html?DbPAR=BASIC">GIMMICKS Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_schedule.html?DbPAR=BASIC">SCHEDULE Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_script.html?DbPAR=BASIC">SCRIPTBINDINGLIBRARY Library</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/03/lib_template.html?DbPAR=BASIC">TEMPLATE Library</a></li>\
                </ul></li>\
            </ul></li>\
    <li><input type="checkbox" id="070103"><label for="070103">Guides</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/macro_recording.html?DbPAR=BASIC">記錄巨集</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/control_properties.html?DbPAR=BASIC">在對話方塊編輯器中變更控制項的屬性</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/insert_control.html?DbPAR=BASIC">在對話方塊編輯器中建立控制項</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/sample_code.html?DbPAR=BASIC">對話方塊編輯器中控制項的程式設計示例</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/show_dialog.html?DbPAR=BASIC">Opening a Dialog With Basic</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/create_dialog.html?DbPAR=BASIC">建立 Basic 對話方塊</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01030400.html?DbPAR=BASIC">管理程式庫和模組</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01020100.html?DbPAR=BASIC">使用變數</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01020200.html?DbPAR=BASIC">使用物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01030300.html?DbPAR=BASIC">除錯 Basic 程式</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/shared/01040000.html?DbPAR=BASIC">事件驅動的巨集</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/basic_examples.html?DbPAR=BASIC">Basic Programming Examples</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/basic_2_python.html?DbPAR=BASIC">Basic to Python</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/guide/access2base.html?DbPAR=BASIC">Access2Base</a></li>\
            </ul></li>\
        </ul></li>\
    <li><input type="checkbox" id="0702"><label for="0702">Python Scripts Help</label><ul>\
    <li><input type="checkbox" id="070201"><label for="070201">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/main0000.html?DbPAR=BASIC">Python Scripts</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/python_ide.html?DbPAR=BASIC">IDE for Python</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/python_locations.html?DbPAR=BASIC">Python Scripts Organization</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/python_shell.html?DbPAR=BASIC">Python Interactive Shell</a></li>\
            </ul></li>\
    <li><input type="checkbox" id="070202"><label for="070202">Programming with Python</label><ul>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/python_programming.html?DbPAR=BASIC">Python : Programming with Python</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/python_examples.html?DbPAR=BASIC">Python examples</a></li>\
    <li><a target="_top" href="zh-TW/text/sbasic/python/python_2_basic.html?DbPAR=BASIC">Python to Basic</a></li>\
            </ul></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="08"><label for="08">Spreadsheets (Calc)</label><ul>\
    <li><input type="checkbox" id="0801"><label for="0801">一般資訊與使用者介面用法</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/main0000.html?DbPAR=CALC">歡迎使用 LibreOffice Calc 說明</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0503.html?DbPAR=CALC">LibreOffice Calc 的功能</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/keyboard.html?DbPAR=CALC">組合鍵 (LibreOffice Calc 協助工具)</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/04/01020000.html?DbPAR=CALC">工作表文件的快捷鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/05/02140000.html?DbPAR=CALC">LibreOffice Calc 中的錯誤碼</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060112.html?DbPAR=CALC">LibreOffice Calc 中程式設計的 Add-In</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/main.html?DbPAR=CALC">使用 LibreOffice Calc 的說明</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0802"><label for="0802">指令與選單參照</label><ul>\
    <li><input type="checkbox" id="080201"><label for="080201">選單</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/main0100.html?DbPAR=CALC">功能表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0101.html?DbPAR=CALC">檔案</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0102.html?DbPAR=CALC">編輯</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0103.html?DbPAR=CALC">檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0104.html?DbPAR=CALC">插入</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0105.html?DbPAR=CALC">格式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0116.html?DbPAR=CALC">工作表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0112.html?DbPAR=CALC">資料</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0106.html?DbPAR=CALC">工具</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0107.html?DbPAR=CALC">視窗</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0108.html?DbPAR=CALC">說明</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="080202"><label for="080202">工具列</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/main0200.html?DbPAR=CALC">工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0202.html?DbPAR=CALC">格式列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0203.html?DbPAR=CALC">繪圖物件特性列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0205.html?DbPAR=CALC">文字格式列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0206.html?DbPAR=CALC">編輯列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0208.html?DbPAR=CALC">狀態列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0210.html?DbPAR=CALC">列印預覽列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0214.html?DbPAR=CALC">影像列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/main0218.html?DbPAR=CALC">工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0201.html?DbPAR=CALC">標準列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0212.html?DbPAR=CALC">表格資料列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0213.html?DbPAR=CALC">[表單瀏覽] 工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0214.html?DbPAR=CALC">查詢設計列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0226.html?DbPAR=CALC">表單設計工具列</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0803"><label for="0803">函式類型與運算子</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060000.html?DbPAR=CALC">函式精靈</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060100.html?DbPAR=CALC">函式 (依分類)</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060107.html?DbPAR=CALC">陣列函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060120.html?DbPAR=CALC">位元操作函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060101.html?DbPAR=CALC">資料庫函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060102.html?DbPAR=CALC">日期和時間函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060103.html?DbPAR=CALC">財務函式第一部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060119.html?DbPAR=CALC">財務函式第二部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060118.html?DbPAR=CALC">財務函式第三部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060104.html?DbPAR=CALC">資訊函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060105.html?DbPAR=CALC">邏輯函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060106.html?DbPAR=CALC">數學函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060108.html?DbPAR=CALC">統計函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060181.html?DbPAR=CALC">統計函式第一部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060182.html?DbPAR=CALC">統計函式第二部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060183.html?DbPAR=CALC">統計函式第三部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060184.html?DbPAR=CALC">統計函式第四部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060185.html?DbPAR=CALC">統計函式第五部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060109.html?DbPAR=CALC">試算表函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060110.html?DbPAR=CALC">文字函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060111.html?DbPAR=CALC">Add-In 函式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060115.html?DbPAR=CALC">Add-In 函式，分析函式清單第一部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060116.html?DbPAR=CALC">Add-In 函式，分析函式清單第二部分</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/01/04060199.html?DbPAR=CALC">LibreOffice Calc 中的運算子</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/userdefined_function.html?DbPAR=CALC">使用者定義的函式</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0804"><label for="0804">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/webquery.html?DbPAR=CALC">將外部資料插入表格 (WebQuery)</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/html_doc.html?DbPAR=CALC">儲存與開啟 HTML 中的試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/csv_formula.html?DbPAR=CALC">匯入與匯出文字檔案</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redaction.html?DbPAR=CALC">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0805"><label for="0805">格式化</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/text_rotate.html?DbPAR=CALC">旋轉文字</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/text_wrap.html?DbPAR=CALC">寫入多行文字</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/text_numbers.html?DbPAR=CALC">將數字格式化為文字</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/super_subscript.html?DbPAR=CALC">文字上標/下標</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/row_height.html?DbPAR=CALC">變更列高或欄寬</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellstyle_conditional.html?DbPAR=CALC">套用條件式格式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellstyle_minusvalue.html?DbPAR=CALC">標明負數</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellstyle_by_formula.html?DbPAR=CALC">依公式指定格式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/integer_leading_zero.html?DbPAR=CALC">輸入具有前導零的數字</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/format_table.html?DbPAR=CALC">格式化試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/format_value.html?DbPAR=CALC">格式化具有小數點的數字</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/value_with_name.html?DbPAR=CALC">命名儲存格</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/table_rotate.html?DbPAR=CALC">旋轉表格 (轉置)</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/rename_table.html?DbPAR=CALC">重新命名試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/year2000.html?DbPAR=CALC">19xx/20xx 年</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/rounding_numbers.html?DbPAR=CALC">使用捨去數字</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/currency_format.html?DbPAR=CALC">貨幣格式的儲存格</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/autoformat.html?DbPAR=CALC">使用表格的自動格式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/note_insert.html?DbPAR=CALC">插入和編輯評註</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/design.html?DbPAR=CALC">選取試算表的主題</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/fraction_enter.html?DbPAR=CALC">輸入分數</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0806"><label for="0806">篩選與排序</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/filters.html?DbPAR=CALC">套用篩選</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/specialfilter.html?DbPAR=CALC">篩選：套用進階篩選</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/autofilter.html?DbPAR=CALC">套用自動篩選</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/sorted_list.html?DbPAR=CALC">套用排序清單</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0807"><label for="0807">列印</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/print_title_row.html?DbPAR=CALC">列印每頁的列或欄</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/print_landscape.html?DbPAR=CALC">以橫向格式列印試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/print_details.html?DbPAR=CALC">列印試算表詳細資訊</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/print_exact.html?DbPAR=CALC">定義列印的頁數</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0808"><label for="0808">資料範圍</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/database_define.html?DbPAR=CALC">定義資料庫範圍</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/database_filter.html?DbPAR=CALC">篩選儲存格範圍</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/database_sort.html?DbPAR=CALC">排序資料</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0809"><label for="0809">樞紐分析表</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot.html?DbPAR=CALC">樞紐分析表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot_createtable.html?DbPAR=CALC">建立樞紐分析表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot_deletetable.html?DbPAR=CALC">刪除樞紐分析表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot_edittable.html?DbPAR=CALC">編輯資料助理表格</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot_filtertable.html?DbPAR=CALC">篩選樞紐分析表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot_tipps.html?DbPAR=CALC">選取樞紐分析表輸出範圍</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/datapilot_updatetable.html?DbPAR=CALC">更新資料助理表格</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="08091"><label for="08091">Pivot Chart</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/pivotchart.html?DbPAR=CALC">Pivot Chart</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/pivotchart_create.html?DbPAR=CALC">Creating Pivot Charts</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/pivotchart_edit.html?DbPAR=CALC">Editing Pivot Charts</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/pivotchart_filter.html?DbPAR=CALC">Filtering Pivot Charts</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/pivotchart_update.html?DbPAR=CALC">Pivot Chart Update</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/pivotchart_delete.html?DbPAR=CALC">Deleting Pivot Charts</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="0810"><label for="0810">分析藍本</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/scenario.html?DbPAR=CALC">使用分析藍本</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0811"><label for="0811">參照</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/relativ_absolut_ref.html?DbPAR=CALC">位址與參照，絕對與相對</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellreferences.html?DbPAR=CALC">參照其他文件的儲存格</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellreferences_url.html?DbPAR=CALC">參照其他試算表與參照 URL</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellreference_dragdrop.html?DbPAR=CALC">依拖放參照儲存格</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/address_auto.html?DbPAR=CALC">識別名稱為定址</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0812"><label for="0812">檢視、選取、複製</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/table_view.html?DbPAR=CALC">變更表格檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/formula_value.html?DbPAR=CALC">顯示公式或值</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/line_fix.html?DbPAR=CALC">固定列或欄作為標題</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/multi_tables.html?DbPAR=CALC">導覽試算表分頁</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/edit_multitables.html?DbPAR=CALC">複製到多個試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cellcopy.html?DbPAR=CALC">僅複製可見的存儲格</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/mark_cells.html?DbPAR=CALC">選取多個儲存格</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0813"><label for="0813">公式與計算</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/formulas.html?DbPAR=CALC">用公式計算</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/formula_copy.html?DbPAR=CALC">複製公式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/formula_enter.html?DbPAR=CALC">輸入公式</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/formula_value.html?DbPAR=CALC">顯示公式或值</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/calculate.html?DbPAR=CALC">在試算表中計算</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/calc_date.html?DbPAR=CALC">利用日期和時間計算</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/calc_series.html?DbPAR=CALC">自動計算數列</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/calc_timevalues.html?DbPAR=CALC">計算時間差異值</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/matrixformula.html?DbPAR=CALC">輸入矩陣公式</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0814"><label for="0814">保護</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cell_protect.html?DbPAR=CALC">防止儲存格變更</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/cell_unprotect.html?DbPAR=CALC">取消保護儲存格</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0815"><label for="0815">其他</label><ul>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/auto_off.html?DbPAR=CALC">關閉自動變更</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/consolidate.html?DbPAR=CALC">合併計算資料</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/goalseek.html?DbPAR=CALC">套用目標搜尋</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/multioperation.html?DbPAR=CALC">套用多重運算</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/multitables.html?DbPAR=CALC">套用多個試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/scalc/guide/validity.html?DbPAR=CALC">儲存格內容的有效性</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="05"><label for="05">圖表</label><ul>\
    <li><input type="checkbox" id="0501"><label for="0501">一般資訊</label><ul>\
    <li><a target="_top" href="zh-TW/text/schart/main0000.html?DbPAR=CHART">LibreOffice 中的圖表</a></li>\
    <li><a target="_top" href="zh-TW/text/schart/main0503.html?DbPAR=CHART">LibreOffice Chart 的功能</a></li>\
    <li><a target="_top" href="zh-TW/text/schart/04/01020000.html?DbPAR=CHART">圖表的組合鍵</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="01"><label for="01">LibreOffice Installation</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">變更 Microsoft Office 文件類型的關聯</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/profile_safe_mode.html?DbPAR=SHARED">Safe Mode</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="10"><label for="10">常見說明主題</label><ul>\
    <li><input type="checkbox" id="1001"><label for="1001">一般資訊</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/main0400.html?DbPAR=SHARED">組合鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/00/00000005.html?DbPAR=SHARED">一般詞彙表</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/00/00000002.html?DbPAR=SHARED">網際網路術語詞彙表</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/accessibility.html?DbPAR=SHARED">LibreOffice 中的協助工具</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/keyboard.html?DbPAR=SHARED">組合鍵 (LibreOffice 協助工具))</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/04/01010000.html?DbPAR=SHARED">LibreOffice 中的一般組合鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/version_number.html?DbPAR=SHARED">版本和建置號碼</a></li>\
</ul></li>\
    <li><input type="checkbox" id="1002"><label for="1002">LibreOffice 與 Microsoft Office</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/ms_user.html?DbPAR=SHARED">使用 Microsoft Office 和 LibreOffice</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/microsoft_terms.html?DbPAR=SHARED">比較 Microsoft Office 和 LibreOffice 術語</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/ms_import_export_limitations.html?DbPAR=SHARED">關於轉換 Microsoft Office 文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/ms_doctypes.html?DbPAR=SHARED">變更 Microsoft Office 文件類型的關聯</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1004"><label for="1004">LibreOffice 選項</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01000000.html?DbPAR=SHARED">選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010100.html?DbPAR=SHARED">使用者資料</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010200.html?DbPAR=SHARED">一般</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010300.html?DbPAR=SHARED">路徑</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010400.html?DbPAR=SHARED">撰寫輔助</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010600.html?DbPAR=SHARED">一般</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010700.html?DbPAR=SHARED">字型</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010800.html?DbPAR=SHARED">檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01010900.html?DbPAR=SHARED">列印選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01012000.html?DbPAR=SHARED">Application Colors</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01013000.html?DbPAR=SHARED">協助工具</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/java.html?DbPAR=SHARED">Advanced</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/expertconfig.html?DbPAR=SHARED">Expert Configuration</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/BasicIDE.html?DbPAR=SHARED">Basic IDE</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/opencl.html?DbPAR=SHARED">Open CL</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01020000.html?DbPAR=SHARED">載入/儲存選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01030000.html?DbPAR=SHARED">網際網路選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01040000.html?DbPAR=SHARED">文字文件選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01050000.html?DbPAR=SHARED">HTML 文件選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01060000.html?DbPAR=SHARED">試算表選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01070000.html?DbPAR=SHARED">簡報選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01080000.html?DbPAR=SHARED">繪圖選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01090000.html?DbPAR=SHARED">公式</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01110000.html?DbPAR=SHARED">圖表選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01130100.html?DbPAR=SHARED">VBA 屬性</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01130200.html?DbPAR=SHARED">Microsoft Office</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01140000.html?DbPAR=SHARED">語言</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01150000.html?DbPAR=SHARED">語言設定選項</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/optionen/01160000.html?DbPAR=SHARED">資料來源選項</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1005"><label for="1005">精靈</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01000000.html?DbPAR=SHARED">精靈</a></li>\
    <li><input type="checkbox" id="100501"><label for="100501">信函精靈</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01010000.html?DbPAR=SHARED">信件精靈</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100502"><label for="100502">傳真精靈</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01020000.html?DbPAR=SHARED">傳真精靈</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100504"><label for="100504">議程精靈</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01040000.html?DbPAR=SHARED">議程精靈</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100506"><label for="100506">HTML 匯出精靈</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01110000.html?DbPAR=SHARED">HTML 匯出</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="100510"><label for="100510">文件轉換精靈</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01130000.html?DbPAR=SHARED">文件轉換器</a></li>\
			</ul></li>\
    <li><a target="_top" href="zh-TW/text/shared/autopi/01150000.html?DbPAR=SHARED">歐元轉換器精靈</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1006"><label for="1006">設定 LibreOffice</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/configure_overview.html?DbPAR=SHARED">配置 LibreOffice</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/packagemanager.html?DbPAR=SHARED">擴充軟體管理程式</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/flat_icons.html?DbPAR=SHARED">變更圖示檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/edit_symbolbar.html?DbPAR=SHARED">將按鈕增加到工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/workfolder.html?DbPAR=SHARED">變更您的工作目錄</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/standard_template.html?DbPAR=SHARED">變更預設範本</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_addressbook.html?DbPAR=SHARED">註冊通訊錄</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/formfields.html?DbPAR=SHARED">插入與編輯按鈕</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1007"><label for="1007">處理使用者介面</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/navigator_setcursor.html?DbPAR=SHARED">快速跳至物件之導覽</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/navigator.html?DbPAR=SHARED">文件摘要的助手</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/autohide.html?DbPAR=SHARED">顯示、停駐和隱藏視窗</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/textmode_change.html?DbPAR=SHARED">在插入模式和覆寫模式之間切換</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/floating_toolbar.html?DbPAR=SHARED">使用工具列</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="10071"><label for="10071">Digital Signatures</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/digital_signatures.html?DbPAR=SHARED">關於數位簽名</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/digitalsign_send.html?DbPAR=SHARED">套用數位簽名</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/ref_pdf_export_digital_signature.html?DbPAR=SHARED">PDF Export Digital Signature</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/signexistingpdf.html?DbPAR=SHARED">Signing Existing PDF</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/01/addsignatureline.html?DbPAR=SHARED">Adding Signature Line in Text Documents</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/01/signsignatureline.html?DbPAR=SHARED">Signing the Signature Line</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
                </ul></li>\
    <li><input type="checkbox" id="1008"><label for="1008">列印、傳真、寄送</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/labels_database.html?DbPAR=SHARED">列印地址標籤</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/print_blackwhite.html?DbPAR=SHARED">以黑白色列印</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/email.html?DbPAR=SHARED">以電子郵件方式傳送文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/fax.html?DbPAR=SHARED">傳送傳真與配置 LibreOffice 的傳真設定</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1009"><label for="1009">拖曳並放開</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop.html?DbPAR=SHARED">在 LibreOffice 文件中拖放</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/dragdroptext.html?DbPAR=SHARED">在文件中移動並複製文字</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">複製試算表區塊到文字文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">在文件間複製圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">從圖庫複製圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_beamer.html?DbPAR=SHARED">在資料來源檢視中拖放</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1010"><label for="1010">複製與貼上</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/copy_drawfunctions.html?DbPAR=SHARED">將繪圖物件複製到其他文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_graphic.html?DbPAR=SHARED">在文件間複製圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_fromgallery.html?DbPAR=SHARED">從圖庫複製圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_table.html?DbPAR=SHARED">複製試算表區塊到文字文件</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1012"><label for="1012">圖表</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/chart_insert.html?DbPAR=SHARED">插入圖表</a></li>\
    <li><a target="_top" href="zh-TW/text/schart/main0000.html?DbPAR=SHARED">LibreOffice 中的圖表</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1013"><label for="1013">Load, Save, Import, Export, PDF</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/doc_open.html?DbPAR=SHARED">開啟文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/import_ms.html?DbPAR=SHARED">開啟以其他格式儲存的文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/doc_save.html?DbPAR=SHARED">儲存文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/doc_autosave.html?DbPAR=SHARED">自動儲存文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/export_ms.html?DbPAR=SHARED">以其他格式儲存文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/ref_pdf_export.html?DbPAR=SHARED">匯出為 PDF 文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_dbase2office.html?DbPAR=SHARED">以文字格式匯入與匯出資料</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/openpgp.html?DbPAR=SHARED">OpenPGP</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1014"><label for="1014">連結與參照</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/hyperlink_insert.html?DbPAR=SHARED">插入超連結</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/hyperlink_rel_abs.html?DbPAR=SHARED">相對和絕對連結</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/hyperlink_edit.html?DbPAR=SHARED">編輯超連結</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1015"><label for="1015">文件版本追蹤</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining_doccompare.html?DbPAR=SHARED">比較文件的版本</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining_docmerge.html?DbPAR=SHARED">合併版本</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining_enter.html?DbPAR=SHARED">記錄變更</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining.html?DbPAR=SHARED">記錄和顯示變更</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining_accept.html?DbPAR=SHARED">接受或拒絕變更</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining_versions.html?DbPAR=SHARED">版本管理</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1016"><label for="1016">標籤與名片</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/labels.html?DbPAR=SHARED">建立與列印標籤和名片</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1018"><label for="1018">插入外部資料</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/copytable2application.html?DbPAR=SHARED">插入試算表的資料</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/copytext2application.html?DbPAR=SHARED">插入文字文件的資料</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/insert_bitmap.html?DbPAR=SHARED">插入、編輯、儲存點陣圖</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/dragdrop_gallery.html?DbPAR=SHARED">將圖形加入圖庫</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1019"><label for="1019">自動函式</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/autocorr_url.html?DbPAR=SHARED">關閉自動 URL 識別</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1020"><label for="1020">搜尋與取代</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_search2.html?DbPAR=SHARED">使用表單篩選進行搜尋</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_search.html?DbPAR=SHARED">搜尋表格文件和表單文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/02100001.html?DbPAR=SHARED">常規表述式的清單</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="1021"><label for="1021">指引</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/guide/linestyles.html?DbPAR=SHARED">套用線條樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/text_color.html?DbPAR=SHARED">變更文字的顏色</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/change_title.html?DbPAR=SHARED">變更文件的題名</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/round_corner.html?DbPAR=SHARED">建立圓角</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/background.html?DbPAR=SHARED">定義背景顏色或背景圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/lineend_define.html?DbPAR=SHARED">定義線條端點</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/linestyle_define.html?DbPAR=SHARED">定義線條樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/insert_graphic_drawit.html?DbPAR=SHARED">編輯圖形物件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/line_intext.html?DbPAR=SHARED">在文字中畫線</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/aaa_start.html?DbPAR=SHARED">第一步</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/gallery_insert.html?DbPAR=SHARED">從圖庫插入物件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/space_hyphen.html?DbPAR=SHARED">Inserting Non-breaking Spaces, Hyphens and Soft Hyphens</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/insert_specialchar.html?DbPAR=SHARED">插入特殊字元</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/tabs.html?DbPAR=SHARED">插入並編輯定位鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/protection.html?DbPAR=SHARED">LibreOffice 中的保護內容</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redlining_protect.html?DbPAR=SHARED">保護記錄</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/pageformat_max.html?DbPAR=SHARED">選取頁面上最大的可列印範圍</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/measurement_units.html?DbPAR=SHARED">選擇定量單位</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/language_select.html?DbPAR=SHARED">選取文件語言</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_tabledefine.html?DbPAR=SHARED">表格設計</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/numbering_stop.html?DbPAR=SHARED">關閉個別段落的編號/項目符號</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="09"><label for="09">Database Functionality (Base)</label><ul>\
    <li><input type="checkbox" id="0901"><label for="0901">一般資訊</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/explorer/database/main.html?DbPAR=SHARED">LibreOffice 資料庫</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/database_main.html?DbPAR=SHARED">資料庫簡介</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_new.html?DbPAR=SHARED">建立新的資料庫</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_tables.html?DbPAR=SHARED">使用表格</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_queries.html?DbPAR=SHARED">使用查詢</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_forms.html?DbPAR=SHARED">使用表單</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_reports.html?DbPAR=SHARED">建立報表</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_register.html?DbPAR=SHARED">註冊與刪除資料庫</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_im_export.html?DbPAR=SHARED">對 Base 匯入及匯出資料</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/data_enter_sql.html?DbPAR=SHARED">執行 SQL 指令</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="04"><label for="04">Presentations (Impress)</label><ul>\
    <li><input type="checkbox" id="0401"><label for="0401">一般資訊與使用者介面用法</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/main0000.html?DbPAR=IMPRESS">歡迎使用 LibreOffice Impress 說明</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0503.html?DbPAR=IMPRESS">LibreOffice Impress 的功能</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/keyboard.html?DbPAR=IMPRESS">使用 LibreOffice Impress 中的捷徑鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/04/01020000.html?DbPAR=IMPRESS">LibreOffice Impress 的快捷鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/04/presenter.html?DbPAR=IMPRESS">Presenter Console Keyboard Shortcuts</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/main.html?DbPAR=IMPRESS">有關使用 LibreOffice Impress 的說明</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0402"><label for="0402">指令與選單參照</label><ul>\
    <li><input type="checkbox" id="04020101"><label for="04020101">選單</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/main0100.html?DbPAR=IMPRESS">選單</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0101.html?DbPAR=IMPRESS">檔案</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main_edit.html?DbPAR=IMPRESS">Edit</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0103.html?DbPAR=IMPRESS">檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0104.html?DbPAR=IMPRESS">插入</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main_format.html?DbPAR=IMPRESS">Format</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main_slide.html?DbPAR=IMPRESS">Slide</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0114.html?DbPAR=IMPRESS">投影片放映</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main_tools.html?DbPAR=IMPRESS">Tools</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0107.html?DbPAR=IMPRESS">視窗</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0108.html?DbPAR=IMPRESS">說明</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="04020102"><label for="04020102">工具列</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/main0200.html?DbPAR=IMPRESS">工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0202.html?DbPAR=IMPRESS">線條與填入列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0203.html?DbPAR=IMPRESS">文字格式列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0204.html?DbPAR=IMPRESS">投影片檢視中的物件工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0206.html?DbPAR=IMPRESS">狀態列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0209.html?DbPAR=IMPRESS">尺規</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0210.html?DbPAR=IMPRESS">繪圖列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0211.html?DbPAR=IMPRESS">大綱工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0212.html?DbPAR=IMPRESS">投影片瀏覽列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0213.html?DbPAR=IMPRESS">選項列</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0214.html?DbPAR=IMPRESS">Image Bar</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0201.html?DbPAR=IMPRESS">標準列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0213.html?DbPAR=IMPRESS">[表單瀏覽] 工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0226.html?DbPAR=IMPRESS">表單設計工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0227.html?DbPAR=IMPRESS">編輯接點列</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="0403"><label for="0403">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/html_export.html?DbPAR=IMPRESS">以 HTML 格式儲存簡報</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/html_import.html?DbPAR=IMPRESS">匯入 HTML 頁到簡報</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">載入顏色、漸層色圖案和陰影線清單</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">以 GIF 格式匯出動畫</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">在投影片中包括試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">插入圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/page_copy.html?DbPAR=IMPRESS">從其他簡報複製投影片</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redaction.html?DbPAR=IMPRESS">Redaction</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0404"><label for="0404">格式化</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/palette_files.html?DbPAR=IMPRESS">載入顏色、漸層色圖案和陰影線清單</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">載入線條和箭頭樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/color_define.html?DbPAR=IMPRESS">定義自訂顏色</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/gradient.html?DbPAR=IMPRESS">建立漸層色圖案填入</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/eyedropper.html?DbPAR=IMPRESS">替代顏色</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/align_arrange.html?DbPAR=IMPRESS">排序, 對齊與分布物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/background.html?DbPAR=IMPRESS">變更投影片背景填入</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/footer.html?DbPAR=IMPRESS">新增頁首或頁尾至所有投影片</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/masterpage.html?DbPAR=IMPRESS">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/move_object.html?DbPAR=IMPRESS">移動物件</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0405"><label for="0405">正在列印</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/printing.html?DbPAR=IMPRESS">列印簡報</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/print_tofit.html?DbPAR=IMPRESS">列印投影片以配合頁面大小</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0406"><label for="0406">效果</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/animated_gif_save.html?DbPAR=IMPRESS">以 GIF 格式匯出動畫</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/animated_objects.html?DbPAR=IMPRESS">簡報投影片中的動畫物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/animated_slidechange.html?DbPAR=IMPRESS">動畫切換投影片</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/cross_fading.html?DbPAR=IMPRESS">漸漸隱出兩個物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/animated_gif_create.html?DbPAR=IMPRESS">建立動畫 GIF 影像</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0407"><label for="0407">物件、圖形、點陣圖</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/combine_etc.html?DbPAR=IMPRESS">組合物件並建構形狀</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/groups.html?DbPAR=IMPRESS">分組物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/draw_sector.html?DbPAR=IMPRESS">繪圖扇區和區段</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/duplicate_object.html?DbPAR=IMPRESS">製作物件複本</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/rotate_object.html?DbPAR=IMPRESS">旋轉物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/join_objects3d.html?DbPAR=IMPRESS">組合 3D 物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/join_objects.html?DbPAR=IMPRESS">連結線條</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">轉換文字字元為繪圖物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/vectorize.html?DbPAR=IMPRESS">將點陣圖影像轉換成向量圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/3d_create.html?DbPAR=IMPRESS">將平面物件轉換成曲線、多邊形以及 3D 物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_arrow_styles.html?DbPAR=IMPRESS">載入線條和箭頭樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_draw.html?DbPAR=IMPRESS">繪製曲線</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_edit.html?DbPAR=IMPRESS">編輯曲線</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/graphic_insert.html?DbPAR=IMPRESS">插入圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/table_insert.html?DbPAR=IMPRESS">在投影片中包括試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/move_object.html?DbPAR=IMPRESS">移動物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/select_object.html?DbPAR=IMPRESS">選取基礎物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/orgchart.html?DbPAR=IMPRESS">建立流程圖</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0409"><label for="0409">Text in Presentations</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/text_enter.html?DbPAR=IMPRESS">加入文字</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/text2curve.html?DbPAR=IMPRESS">轉換文字字元為繪圖物件</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0410"><label for="0410">檢視</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/arrange_slides.html?DbPAR=IMPRESS">變更投影片順序</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/change_scale.html?DbPAR=IMPRESS">使用鍵盤縮放</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="0411"><label for="0411">投影片放映</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/show.html?DbPAR=IMPRESS">顯示投影片放映</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/presenter_console.html?DbPAR=IMPRESS">Using the Presenter Console</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/impress_remote.html?DbPAR=IMPRESS">Impress Remote Guide</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/individual.html?DbPAR=IMPRESS">建立自訂投影片放映</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/rehearse_timings.html?DbPAR=IMPRESS">投影片變更的排練計時</a></li>\
         </ul></li>\
     </ul></li></ul>\
    <ul><li><input type="checkbox" id="03"><label for="03">Formulas (Math)</label><ul>\
    <li><input type="checkbox" id="0301"><label for="0301">一般資訊與使用者介面用法</label><ul>\
    <li><a target="_top" href="zh-TW/text/smath/main0000.html?DbPAR=MATH">歡迎使用 LibreOffice Math 說明</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/main0503.html?DbPAR=MATH">LibreOffice Math 功能</a></li>\
    <li><input type="checkbox" id="030101"><label for="030101">LibreOffice Formula Elements</label><ul>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090100.html?DbPAR=MATH">一元/二元運算子</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090200.html?DbPAR=MATH">關係</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090800.html?DbPAR=MATH">集合運算</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090400.html?DbPAR=MATH">函式</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090300.html?DbPAR=MATH">運算子</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090600.html?DbPAR=MATH">屬性</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090500.html?DbPAR=MATH">括號</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03090700.html?DbPAR=MATH">格式</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/01/03091600.html?DbPAR=MATH">其他圖示</a></li>\
            </ul></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/main.html?DbPAR=MATH">使用 LibreOffice Math 的說明</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/keyboard.html?DbPAR=MATH">組合鍵 (LibreOffice Math 協助工具)</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0302"><label for="0302">指令與選單參照</label><ul>\
    <li><a target="_top" href="zh-TW/text/smath/main0100.html?DbPAR=MATH">功能表</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/main0200.html?DbPAR=MATH">工具列</a></li>\
        </ul></li>\
    <li><input type="checkbox" id="0303"><label for="0303">處理公式</label><ul>\
    <li><a target="_top" href="zh-TW/text/smath/guide/align.html?DbPAR=MATH">手動對齊公式部份</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/attributes.html?DbPAR=MATH">變更預設屬性</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/brackets.html?DbPAR=MATH">合併括號內的公式部份</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/comment.html?DbPAR=MATH">輸入評註</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/newline.html?DbPAR=MATH">輸入斷行符號</a></li>\
    <li><a target="_top" href="zh-TW/text/smath/guide/parentheses.html?DbPAR=MATH">插入括號</a></li>\
        </ul></li>\
    </ul></li></ul>\
    <ul><li><input type="checkbox" id="02"><label for="02">Text Documents (Writer)</label><ul>\
    <li><input type="checkbox" id="0201"><label for="0201">一般資訊與使用者介面用法</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/main0000.html?DbPAR=WRITER">歡迎使用 LibreOffice Writer 說明</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0503.html?DbPAR=WRITER">LibreOffice Writer 的功能</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/main.html?DbPAR=WRITER">使用 LibreOffice Writer 的說明</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/resize_navigator.html?DbPAR=WRITER">停駐或變更視窗大小</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/04/01020000.html?DbPAR=WRITER">LibreOffice Writer 的組合鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/words_count.html?DbPAR=WRITER">統計字詞個數</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/keyboard.html?DbPAR=WRITER">使用組合鍵 (LibreOffice Writer 協助工具)</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0202"><label for="0202">指令與選單參照</label><ul>\
    <li><input type="checkbox" id="020201"><label for="020201">選單</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/main0100.html?DbPAR=WRITER">選單</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0101.html?DbPAR=WRITER">檔案</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0102.html?DbPAR=WRITER">編輯</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0103.html?DbPAR=WRITER">檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0104.html?DbPAR=WRITER">插入</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0105.html?DbPAR=WRITER">格式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0115.html?DbPAR=WRITER">Styles</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0110.html?DbPAR=WRITER">表格</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0120.html?DbPAR=WRITER">Form Menu</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0106.html?DbPAR=WRITER">工具</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0107.html?DbPAR=WRITER">視窗</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0108.html?DbPAR=WRITER">說明</a></li>\
			</ul></li>\
    <li><input type="checkbox" id="020202"><label for="020202">工具列</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/main0200.html?DbPAR=WRITER">工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0202.html?DbPAR=WRITER">文字物件列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0203.html?DbPAR=WRITER">影像列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0204.html?DbPAR=WRITER">表格列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0205.html?DbPAR=WRITER">繪圖物件特性列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0206.html?DbPAR=WRITER">項目符號與編號列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0208.html?DbPAR=WRITER">狀態列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0210.html?DbPAR=WRITER">Print Preview</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0213.html?DbPAR=WRITER">尺規</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0214.html?DbPAR=WRITER">編輯列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0215.html?DbPAR=WRITER">外框列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0216.html?DbPAR=WRITER">OLE 物件列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/main0220.html?DbPAR=WRITER">文字物件列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0201.html?DbPAR=WRITER">標準列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0212.html?DbPAR=WRITER">表格資料列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0213.html?DbPAR=WRITER">[表單瀏覽] 工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0214.html?DbPAR=WRITER">查詢設計列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0226.html?DbPAR=WRITER">表單設計工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/librelogo/LibreLogo.html?DbPAR=WRITER">LibreLogo 工具列</a></li>\
			</ul></li>\
		</ul></li>\
    <li><input type="checkbox" id="0203"><label for="0203">建立文字文件</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_nav_keyb.html?DbPAR=WRITER">使用鍵盤瀏覽和選取</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_direct_cursor.html?DbPAR=WRITER">使用直接定位游標</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0204"><label for="0204">文字文件中的圖形</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_graphic.html?DbPAR=WRITER">插入圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_graphic_dialog.html?DbPAR=WRITER">從檔案中插入圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_graphic_gallery.html?DbPAR=WRITER">使用拖放功能從圖庫插入圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_graphic_scan.html?DbPAR=WRITER">[插入掃瞄影像]</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_graphic_fromchart.html?DbPAR=WRITER">在文字文件中插入 Calc 圖表</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_graphic_fromdraw.html?DbPAR=WRITER">從 LibreOffice Draw 或 Impress 插入圖形</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0205"><label for="0205">文字文件中的表格</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">開啟或關閉表格中的數字識別</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/tablemode.html?DbPAR=WRITER">使用鍵盤修改列與欄</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/table_delete.html?DbPAR=WRITER">刪除表格或是表格內容</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/table_insert.html?DbPAR=WRITER">插入表格</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/table_repeat_multiple_headers.html?DbPAR=WRITER">在新的頁面上重複表格標題</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/table_sizing.html?DbPAR=WRITER">變更文字表格中列和欄的大小</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0206"><label for="0206">文字文件中的物件</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/anchor_object.html?DbPAR=WRITER">定位物件</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/wrap.html?DbPAR=WRITER">文字環繞物件</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0207"><label for="0207">文字文件中的區段與外框</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/sections.html?DbPAR=WRITER">使用區段</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_frame.html?DbPAR=WRITER">Inserting, Editing, and Linking Frames</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/section_edit.html?DbPAR=WRITER">編輯區塊</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/section_insert.html?DbPAR=WRITER">插入區段</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0208"><label for="0208">目錄與索引</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_userdef.html?DbPAR=WRITER">使用者自訂的索引</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_toc.html?DbPAR=WRITER">建立目錄</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_index.html?DbPAR=WRITER">建立索引目錄</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_multidoc.html?DbPAR=WRITER">涵蓋數個文件的索引</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_literature.html?DbPAR=WRITER">建立參考文獻目錄</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_delete.html?DbPAR=WRITER">編輯或刪除索引與表格條目</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_edit.html?DbPAR=WRITER">更新、編輯與刪除索引和目錄</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_enter.html?DbPAR=WRITER">定義索引或目錄條目</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/indices_form.html?DbPAR=WRITER">格式化索引或目錄</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0209"><label for="0209">文字文件中的欄位指令</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/fields.html?DbPAR=WRITER">關於欄位</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/fields_date.html?DbPAR=WRITER">插入固定或可變日期欄位</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/field_convert.html?DbPAR=WRITER">將欄位轉換成文字</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0210"><label for="0210">瀏覽文字文件</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/dragdroptext.html?DbPAR=WRITER">在文件中移動並複製文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/arrange_chapters.html?DbPAR=WRITER">使用瀏覽重新排序文件</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">利用瀏覽插入超連結</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/navigator.html?DbPAR=WRITER">文字文件的瀏覽</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0211"><label for="0211">在文字文件中計算</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/calculate_multitable.html?DbPAR=WRITER">跨表格計算</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/calculate.html?DbPAR=WRITER">在文字文件中計算</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/calculate_clipboard.html?DbPAR=WRITER">計算與貼上文字文件中的公式結果</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/calculate_intable.html?DbPAR=WRITER">計算表格中的儲存格總和</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/calculate_intext.html?DbPAR=WRITER">計算文字文件中的複雜公式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/calculate_intext2.html?DbPAR=WRITER">顯示不同表格中，表格計算的結果</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0212"><label for="0212">格式化文字文件</label><ul>\
    <li><input type="checkbox" id="021201"><label for="021201">範本與樣式</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/templates_styles.html?DbPAR=WRITER">範本與樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/even_odd_sdw.html?DbPAR=WRITER">在偶數頁和奇數頁上採用不同的頁面樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/change_header.html?DbPAR=WRITER">基於目前頁面建立頁面樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/load_styles.html?DbPAR=WRITER">使用另一個文件或範本中的樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/stylist_fromselect.html?DbPAR=WRITER">從選擇中建立新樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/stylist_update.html?DbPAR=WRITER">從選擇中更新樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/template_create.html?DbPAR=WRITER">建立文件範本</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/template_default.html?DbPAR=WRITER">變更預設範本</a></li>\
			</ul></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/pageorientation.html?DbPAR=WRITER">變更頁面方向 (橫向或縱向)</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_capital.html?DbPAR=WRITER">變更文字的大小寫</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/hidden_text.html?DbPAR=WRITER">隱藏文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">定義不同的頁首與頁尾</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">在頁首或頁尾插入章節名稱和章節號碼</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/shortcut_writing.html?DbPAR=WRITER">輸入時套用文字格式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/reset_format.html?DbPAR=WRITER">重設字型屬性</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/stylist_fillformat.html?DbPAR=WRITER">在填入格式模式中套用樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/wrap.html?DbPAR=WRITER">文字環繞物件</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_centervert.html?DbPAR=WRITER">使用外框以置中頁面上的文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_emphasize.html?DbPAR=WRITER">突顯文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_rotate.html?DbPAR=WRITER">旋轉文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/page_break.html?DbPAR=WRITER">插入與刪除分頁</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/pagestyles.html?DbPAR=WRITER">建立和套用頁面樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/subscript.html?DbPAR=WRITER">使此文字成為上標或下標</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0213"><label for="0213">特殊文字元素</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/captions.html?DbPAR=WRITER">使用標籤</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/conditional_text.html?DbPAR=WRITER">條件文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/conditional_text2.html?DbPAR=WRITER">頁數的條件文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/fields_date.html?DbPAR=WRITER">插入固定或可變日期欄位</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/fields_enter.html?DbPAR=WRITER">新增輸入欄位</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/footer_nextpage.html?DbPAR=WRITER">插入續頁的頁碼</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/footer_pagenumber.html?DbPAR=WRITER">在頁尾中插入頁碼</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/hidden_text.html?DbPAR=WRITER">隱藏文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/header_pagestyles.html?DbPAR=WRITER">定義不同的頁首與頁尾</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/header_with_chapter.html?DbPAR=WRITER">在頁首或頁尾插入章節名稱和章節號碼</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/fields_userdata.html?DbPAR=WRITER">查詢欄位或條件中的使用者資料</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/footnote_usage.html?DbPAR=WRITER">插入和編輯註腳或尾註</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/footnote_with_line.html?DbPAR=WRITER">註腳之間的間隔</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/header_footer.html?DbPAR=WRITER">關於頁首和頁尾</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/header_with_line.html?DbPAR=WRITER">格式化頁首或頁尾</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/text_animation.html?DbPAR=WRITER">使文字呈現動態效果</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/form_letters_main.html?DbPAR=WRITER">建立表單信函</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0214"><label for="0214">自動函式</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/autocorr_except.html?DbPAR=WRITER">新增例外至自動校正清單</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/autotext.html?DbPAR=WRITER">使用自動圖文集</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">輸入時建立有編號或項目編號的清單</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/auto_off.html?DbPAR=WRITER">關閉自動校正</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">自動檢查拼寫</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/number_date_conv.html?DbPAR=WRITER">開啟或關閉表格中的數字識別</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/using_hyphen.html?DbPAR=WRITER">連字符</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0215"><label for="0215">編號與清單</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/captions_numbers.html?DbPAR=WRITER">新增章節編號至標籤</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/auto_numbering.html?DbPAR=WRITER">輸入時建立有編號或項目編號的清單</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/chapter_numbering.html?DbPAR=WRITER">Chapter Numbering</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_tab_innumbering.html?DbPAR=WRITER">Changing the Chapter Level of Numbered and Bulleted Lists</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/join_numbered_lists.html?DbPAR=WRITER">合併編號的清單</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/numbering_lines.html?DbPAR=WRITER">新增行號</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/numbering_paras.html?DbPAR=WRITER">修改已編號清單中的編號</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/number_sequence.html?DbPAR=WRITER">定義編號範圍</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/using_numbered_lists2.html?DbPAR=WRITER">新增編號</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/using_numbering.html?DbPAR=WRITER">編號和編號樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/using_numbered_lists.html?DbPAR=WRITER">新增項目符號</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0216"><label for="0216">拼字檢查、同義詞庫、語言</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/auto_spellcheck.html?DbPAR=WRITER">自動檢查拼寫</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/delete_from_dict.html?DbPAR=WRITER">從使用者自訂字典中移除字詞</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/using_thesaurus.html?DbPAR=WRITER">同義詞詞典</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/spellcheck_dialog.html?DbPAR=WRITER">檢查拼字及文法</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0218"><label for="0218">疑難排解秘訣</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/insert_beforetable.html?DbPAR=WRITER">在頁面頂部的表格前插入文字</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/jump2statusbar.html?DbPAR=WRITER">移至特定書籤</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0219"><label for="0219">Loading, Saving, Importing, Exporting and Redacting</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/send2html.html?DbPAR=WRITER">以 HTML 格式儲存文字文件</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/textdoc_inframe.html?DbPAR=WRITER">插入整個文字文件</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/guide/redaction.html?DbPAR=WRITER">Redaction</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0220"><label for="0220">主控文件</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/globaldoc.html?DbPAR=WRITER">主控文件與子文件</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0221"><label for="0221">連結與參照</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/references.html?DbPAR=WRITER">插入交互參照</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/hyperlinks.html?DbPAR=WRITER">利用瀏覽插入超連結</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0222"><label for="0222">列印</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/printer_tray.html?DbPAR=WRITER">選取印表機送紙匣</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/print_preview.html?DbPAR=WRITER">列印前預覽頁面</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/print_small.html?DbPAR=WRITER">在單張紙上列印多頁</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/pagestyles.html?DbPAR=WRITER">建立和套用頁面樣式</a></li>\
		</ul></li>\
    <li><input type="checkbox" id="0223"><label for="0223">搜尋與取代</label><ul>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/search_regexp.html?DbPAR=WRITER">Using Regular Expressions in Text Searches</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/01/02100001.html?DbPAR=WRITER">常規表述式的清單</a></li>\
		</ul></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="06"><label for="06">HTML Documents (Writer Web)</label><ul>\
    <li><a target="_top" href="zh-TW/text/shared/07/09000000.html?DbPAR=WRITER">網頁</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/02/01170700.html?DbPAR=WRITER">HTML篩選器與表單</a></li>\
    <li><a target="_top" href="zh-TW/text/swriter/guide/send2html.html?DbPAR=WRITER">以 HTML 格式儲存文字文件</a></li>\
	</ul></li></ul>\
    <ul><li><input type="checkbox" id="11"><label for="11">Drawings (Draw)</label><ul>\
    <li><input type="checkbox" id="1101"><label for="1101">General Information and User Interface Usage</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0000.html?DbPAR=DRAW">歡迎使用 LibreOffice Draw 說明</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0503.html?DbPAR=DRAW">LibreOffice Draw 的功能</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/keyboard.html?DbPAR=DRAW">用於繪圖物件的組合鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/04/01020000.html?DbPAR=DRAW">用於繪圖的組合鍵</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/main.html?DbPAR=DRAW">使用 LibreOffice Draw 的說明</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1102"><label for="1102">Command and Menu Reference</label><ul>\
    <li><input type="checkbox" id="11020201"><label for="11020201">Menus</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0100.html?DbPAR=DRAW">功能表</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0101.html?DbPAR=DRAW">檔案</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main_edit.html?DbPAR=DRAW">Edit</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0103.html?DbPAR=DRAW">檢視</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main_insert.html?DbPAR=DRAW">Insert</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main_format.html?DbPAR=DRAW">Format</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main_page.html?DbPAR=DRAW">Page</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main_shape.html?DbPAR=DRAW">Shape</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main_tools.html?DbPAR=DRAW">Tools</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/main0107.html?DbPAR=DRAW">視窗</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0108.html?DbPAR=DRAW">說明</a></li>\
                 </ul></li>\
    <li><input type="checkbox" id="11020202"><label for="11020202">Toolbars</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0200.html?DbPAR=DRAW">工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0210.html?DbPAR=DRAW">繪圖列</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/main0213.html?DbPAR=DRAW">選項列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0201.html?DbPAR=DRAW">標準列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0213.html?DbPAR=DRAW">[表單瀏覽] 工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0226.html?DbPAR=DRAW">表單設計工具列</a></li>\
    <li><a target="_top" href="zh-TW/text/shared/main0227.html?DbPAR=DRAW">編輯接點列</a></li>\
                 </ul></li>\
         </ul></li>\
    <li><input type="checkbox" id="1103"><label for="1103">Loading, Saving, Importing, and Exporting</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/palette_files.html?DbPAR=DRAW">載入顏色、漸層色圖案和陰影線清單</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">插入圖形</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1104"><label for="1104">Formatting</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/palette_files.html?DbPAR=DRAW">載入顏色、漸層色圖案和陰影線清單</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">載入線條和箭頭樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/color_define.html?DbPAR=DRAW">定義自訂顏色</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/gradient.html?DbPAR=DRAW">建立漸層色圖案填入</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/eyedropper.html?DbPAR=DRAW">替代顏色</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/align_arrange.html?DbPAR=DRAW">排序, 對齊與分布物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/background.html?DbPAR=DRAW">變更投影片背景填入</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/masterpage.html?DbPAR=DRAW">Changing and Adding a Master Page</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/move_object.html?DbPAR=DRAW">移動物件</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1105"><label for="1105">Printing</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/printing.html?DbPAR=DRAW">列印簡報</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/print_tofit.html?DbPAR=DRAW">列印投影片以配合頁面大小</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1106"><label for="1106">Effects</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/cross_fading.html?DbPAR=DRAW">漸漸隱出兩個物件</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1107"><label for="1107">Objects, Graphics, and Bitmaps</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/combine_etc.html?DbPAR=DRAW">組合物件並建構形狀</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/draw_sector.html?DbPAR=DRAW">繪圖扇區和區段</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/duplicate_object.html?DbPAR=DRAW">製作物件複本</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/rotate_object.html?DbPAR=DRAW">旋轉物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/join_objects3d.html?DbPAR=DRAW">組合 3D 物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/join_objects.html?DbPAR=DRAW">連結線條</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/text2curve.html?DbPAR=DRAW">轉換文字字元為繪圖物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/vectorize.html?DbPAR=DRAW">將點陣圖影像轉換成向量圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/3d_create.html?DbPAR=DRAW">將平面物件轉換成曲線、多邊形以及 3D 物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_arrow_styles.html?DbPAR=DRAW">載入線條和箭頭樣式</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_draw.html?DbPAR=DRAW">繪製曲線</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/line_edit.html?DbPAR=DRAW">編輯曲線</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/graphic_insert.html?DbPAR=DRAW">插入圖形</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/table_insert.html?DbPAR=DRAW">在投影片中包括試算表</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/move_object.html?DbPAR=DRAW">移動物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/select_object.html?DbPAR=DRAW">選取基礎物件</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/orgchart.html?DbPAR=DRAW">建立流程圖</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1108"><label for="1108">Groups and Layers</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/groups.html?DbPAR=DRAW">分組物件</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/layers.html?DbPAR=DRAW">About Layers</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/layer_new.html?DbPAR=DRAW">Inserting Layers</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/layer_tipps.html?DbPAR=DRAW">Working With Layers</a></li>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/layer_move.html?DbPAR=DRAW">Moving Objects to a Different Layer</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1109"><label for="1109">Text in Drawings</label><ul>\
    <li><a target="_top" href="zh-TW/text/sdraw/guide/text_enter.html?DbPAR=DRAW">加入文字</a></li>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/text2curve.html?DbPAR=DRAW">轉換文字字元為繪圖物件</a></li>\
         </ul></li>\
    <li><input type="checkbox" id="1110"><label for="1110">Viewing</label><ul>\
    <li><a target="_top" href="zh-TW/text/simpress/guide/change_scale.html?DbPAR=DRAW">使用鍵盤縮放</a></li>\
         </ul></li>\
     </ul></li></ul>\
';
