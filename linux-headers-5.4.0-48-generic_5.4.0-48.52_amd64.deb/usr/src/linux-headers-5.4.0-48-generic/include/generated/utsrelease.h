#define UTS_RELEASE "5.4.0-48-generic"
#define UTS_UBUNTU_RELEASE_ABI 48
