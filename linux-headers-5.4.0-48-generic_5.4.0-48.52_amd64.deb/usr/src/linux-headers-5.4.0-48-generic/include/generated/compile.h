/* This file is auto generated, version 52-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#52-Ubuntu SMP Thu Sep 10 10:58:49 UTC 2020"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy01-amd64-010"
#define LINUX_COMPILER "gcc version 9.3.0 (Ubuntu 9.3.0-10ubuntu2)"
